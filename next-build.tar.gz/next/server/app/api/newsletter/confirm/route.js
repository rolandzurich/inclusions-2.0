"use strict";(()=>{var e={};e.id=878,e.ids=[878,2913],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},50852:e=>{e.exports=require("async_hooks")},6113:e=>{e.exports=require("crypto")},84492:e=>{e.exports=require("node:stream")},12781:e=>{e.exports=require("stream")},73837:e=>{e.exports=require("util")},5442:(e,t,n)=>{n.r(t),n.d(t,{headerHooks:()=>g,originalPathname:()=>b,patchFetch:()=>y,requestAsyncStorage:()=>u,routeModule:()=>c,serverHooks:()=>h,staticGenerationAsyncStorage:()=>p,staticGenerationBailout:()=>f});var r={};n.r(r),n.d(r,{GET:()=>m,dynamic:()=>d});var i=n(95419),o=n(69108),a=n(99678),s=n(78070),l=n(42913);let d="force-dynamic";async function m(e){try{let t=new URL(e.url).searchParams.get("token");if(!t)return s.Z.redirect(new URL("/newsletter?error=missing-token",e.url));let{supabaseAdmin:r}=await n.e(8146).then(n.bind(n,78146));if(!r)return s.Z.redirect(new URL("/newsletter?error=service-unavailable",e.url));let{data:i,error:o}=await r.from("newsletter_subscribers").select("*").eq("opt_in_token",t).single();if(o||!i)return s.Z.redirect(new URL("/newsletter?error=invalid-token",e.url));if(i.opt_in_confirmed_at)return s.Z.redirect(new URL("/newsletter?error=already-confirmed",e.url));if(new Date(i.opt_in_expires_at)<new Date)return s.Z.redirect(new URL("/newsletter?error=token-expired",e.url));let{error:a}=await r.from("newsletter_subscribers").update({opt_in_confirmed_at:new Date().toISOString(),status:"confirmed"}).eq("id",i.id);if(a)return console.error("Error confirming subscription:",a),s.Z.redirect(new URL("/newsletter?error=confirmation-failed",e.url));return await (0,l.Q)(i.email,i.first_name||"Liebe/r").catch(e=>console.error("Error sending welcome email:",e)),s.Z.redirect(new URL("/newsletter?success=confirmed",e.url))}catch(t){return console.error("Error confirming newsletter subscription:",t),s.Z.redirect(new URL("/newsletter?error=unknown",e.url))}}let c=new i.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/newsletter/confirm/route",pathname:"/api/newsletter/confirm",filename:"route",bundlePath:"app/api/newsletter/confirm/route"},resolvedPagePath:"/Users/roland/Curser/inclusions-2.0/app/api/newsletter/confirm/route.ts",nextConfigOutput:"",userland:r}),{requestAsyncStorage:u,staticGenerationAsyncStorage:p,serverHooks:h,headerHooks:g,staticGenerationBailout:f}=c,b="/api/newsletter/confirm/route";function y(){return(0,a.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:p})}},42913:(e,t,n)=>{n.d(t,{Q:()=>u,adminEmail:()=>a,fromEmail:()=>o,resend:()=>s,resendApiKey:()=>i,sendBookingConfirmation:()=>d,sendContactConfirmation:()=>l,sendContactNotification:()=>m,sendNewsletterNotification:()=>p,sendNewsletterOptIn:()=>c,sendVIPConfirmation:()=>h,sendVIPNotification:()=>g});var r=n(61788);let i=process.env.RESEND_API_KEY,o=process.env.RESEND_FROM_EMAIL||"noreply@inclusions.zone",a=process.env.RESEND_ADMIN_EMAIL||"info@inclusions.zone";fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:3",message:"Resend init - checking env vars",data:{hasApiKey:!!i,apiKeyPrefix:i?.substring(0,10)||"none",fromEmail:o,adminEmail:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),i&&"re_your-resend-api-key-here"!==i||(console.warn("⚠️ RESEND_API_KEY ist nicht gesetzt oder ist ein Platzhalter. E-Mail-Versand wird nicht funktionieren."),console.warn("⚠️ Formulare funktionieren trotzdem, aber keine E-Mails werden versendet."),fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:10",message:"RESEND_API_KEY missing or placeholder",data:{resendApiKey:i||"undefined"},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}));let s=i&&"re_your-resend-api-key-here"!==i?new r.R(i):null;async function l(e,t){if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:18",message:"sendContactConfirmation called",data:{to:e,name:t,resendIsNull:null===s,fromEmail:o},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),!s)return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:20",message:"Resend is null - returning error",data:{to:e,name:t},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),{error:"Resend nicht konfiguriert"};fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:22",message:"Calling resend.emails.send for contact confirmation",data:{from:o,to:e},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{});let n=await s.emails.send({from:o,to:e,subject:"Vielen Dank f\xfcr deine Anfrage - Inclusions",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ff00ff;">Vielen Dank, ${t}!</h1>
          <p>Wir haben deine Anfrage erhalten und melden uns bald bei dir.</p>
          <p>Bis dahin,<br>Das Inclusions Team</p>
        </body>
      </html>
    `,text:`Vielen Dank, ${t}!

Wir haben deine Anfrage erhalten und melden uns bald bei dir.

Bis dahin,
Das Inclusions Team`});return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:41",message:"Contact confirmation email result",data:{hasError:!!n.error,error:n.error,hasData:!!n.data,emailId:n.data?.id},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{}),n}async function d(e,t,n,r,i){if(!s)return{error:"Resend nicht konfiguriert"};let l=t.split(" ")[0],d=n?` f\xfcr ${n}`:"",m=r&&i?` am ${r} in ${i}`:r?` am ${r}`:i?` in ${i}`:"";return await s.emails.send({from:o,to:e,reply_to:a,subject:"Vielen Dank f\xfcr deine Buchungsanfrage - Inclusions",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.8; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; font-size: 16px;">
          <h1 style="color: #ff00ff; font-size: 24px; margin-bottom: 20px;">Liebe / Lieber ${l}</h1>
          <p style="font-size: 18px; margin-bottom: 15px;">vielen Dank f\xfcr deine Buchungsanfrage${d}${m}.</p>
          <p style="margin-bottom: 15px;">Wir haben deine Anfrage erhalten und werden sie schnellstm\xf6glich pr\xfcfen.</p>
          <p style="margin-bottom: 15px;">Falls es vorab noch Unklarheiten gibt, melden wir uns bei dir.</p>
          <p style="margin-bottom: 15px;">Wir melden uns bald bei dir mit weiteren Details zu deiner Buchung.</p>
          <p style="margin-top: 30px;">Bis bald – wir freuen uns auf deine Anfrage.</p>
          <p style="margin-top: 20px;">Herzlich<br>Dein Inclusions Team</p>
        </body>
      </html>
    `,text:`Liebe / Lieber ${l}

vielen Dank f\xfcr deine Buchungsanfrage${d}${m}.

Wir haben deine Anfrage erhalten und werden sie schnellstm\xf6glich pr\xfcfen.

Falls es vorab noch Unklarheiten gibt, melden wir uns bei dir.
Wir melden uns bald bei dir mit weiteren Details zu deiner Buchung.

Bis bald – wir freuen uns auf deine Anfrage.

Herzlich
Dein Inclusions Team`})}async function m(e){if(!s)return{error:"Resend nicht konfiguriert"};let t=e.bookingType||e.bookingItem?"Buchungsanfrage":"Kontaktanfrage",n=`📧 ${t}${e.bookingItem?`: ${e.bookingItem}`:""}${e.eventDate?` - ${e.eventDate}`:""} - Inclusions`,r=`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #ff00ff;">Neue ${t}</h2>
        
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
          <p><strong>Name:</strong> ${e.name}</p>
          <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
          ${e.phone?`<p><strong>Telefon:</strong> <a href="tel:${e.phone}">${e.phone}</a></p>`:""}
        </div>

        ${e.bookingType||e.bookingItem||e.eventDate||e.eventLocation?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Buchungsdetails</h3>
          ${e.bookingType?`<p><strong>Buchungstyp:</strong> ${e.bookingType}</p>`:""}
          ${e.bookingItem?`<p><strong>Gebuchtes Item:</strong> ${e.bookingItem}</p>`:""}
          ${e.eventDate?`<p><strong>Event-Datum:</strong> ${e.eventDate}</p>`:""}
          ${e.eventLocation?`<p><strong>Event-Ort:</strong> ${e.eventLocation}</p>`:""}
          ${e.eventType?`<p><strong>Event-Typ:</strong> ${e.eventType}</p>`:""}
        </div>
        `:""}

        ${e.message?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Nachricht</h3>
          <p style="white-space: pre-wrap;">${e.message.replace(/\n/g,"<br>")}</p>
        </div>
        `:""}

        ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
        <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
          <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
          ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
          ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
          ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
          ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
        </div>
        `:""}
      </body>
    </html>
  `,i=`Neue ${t}

Kontaktinformationen:
Name: ${e.name}
E-Mail: ${e.email}
${e.phone?`Telefon: ${e.phone}
`:""}
${e.bookingType||e.bookingItem||e.eventDate||e.eventLocation?`Buchungsdetails:
${e.bookingType?`Buchungstyp: ${e.bookingType}
`:""}${e.bookingItem?`Gebuchtes Item: ${e.bookingItem}
`:""}${e.eventDate?`Event-Datum: ${e.eventDate}
`:""}${e.eventLocation?`Event-Ort: ${e.eventLocation}
`:""}${e.eventType?`Event-Typ: ${e.eventType}
`:""}
`:""}${e.message?`Nachricht:
${e.message}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,l=[];if(a)try{let e=await s.emails.send({from:o,to:a,subject:n,html:r,text:i});e.error?console.warn(`⚠️ ${a} Fehler:`,e.error):(console.log(`✅ Kontakt-Benachrichtigung an ${a} gesendet`),l.push({email:a,id:e.data?.id}))}catch(e){console.error(`❌ Fehler beim Senden an ${a}:`,e)}if(0===l.length)try{let e=await s.emails.send({from:o,to:"roland.luthi@gmail.com",subject:n,html:r,text:i});e.error||(console.log("✅ Kontakt-Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback)"),l.push({email:"roland.luthi@gmail.com",id:e.data?.id}))}catch(e){console.error("❌ Fehler:",e)}return l.length>0?{id:l[0].id,data:{results:l}}:{error:"Keine E-Mails versendet"}}async function c(e,t,n){let r;if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:203",message:"sendNewsletterOptIn called",data:{to:e,firstName:t,resendIsNull:null===s,fromEmail:o},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),!s)return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:205",message:"Resend is null - returning error",data:{to:e,firstName:t},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),{error:"Resend nicht konfiguriert"};let i=`http://10.55.55.155/api/newsletter/confirm?token=${n}`;fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:208",message:"Calling resend.emails.send",data:{from:o,to:e,confirmUrl:i},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{});try{if(r=await s.emails.send({from:o,to:e,subject:"Bitte best\xe4tige deine Newsletter-Anmeldung - Inclusions",html:`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
            <h1 style="color: #ff00ff;">Hallo ${t}!</h1>
            <p>Vielen Dank f\xfcr deine Anmeldung zum Inclusions Newsletter.</p>
            <p>Bitte best\xe4tige deine E-Mail-Adresse, indem du auf den folgenden Link klickst:</p>
            <p style="text-align: center; margin: 30px 0;">
              <a href="${i}" style="background-color: #ff00ff; color: white; padding: 12px 24px; text-decoration: none; border-radius: 25px; display: inline-block;">
                Newsletter best\xe4tigen
              </a>
            </p>
            <p>Der Link ist 7 Tage g\xfcltig.</p>
            <p>Bis bald,<br>Das Inclusions Team</p>
          </body>
        </html>
      `,text:`Hallo ${t}!

Vielen Dank f\xfcr deine Anmeldung zum Inclusions Newsletter.

Bitte best\xe4tige deine E-Mail-Adresse:
${i}

Der Link ist 7 Tage g\xfcltig.

Bis bald,
Das Inclusions Team`}),fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:270",message:"resend.emails.send result",data:{hasError:!!r.error,error:r.error,errorMessage:r.error?.message,errorName:r.error?.name,hasData:!!r.data,emailId:r.data?.id,fullResult:JSON.stringify(r)},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{}),r.error){let t={error:r.error,message:r.error?.message,name:r.error?.name,statusCode:r.error?.statusCode,from:o,to:e};console.error("❌ Resend API Fehler (Newsletter Opt-In):",JSON.stringify(t,null,2)),r.error?.message?.includes("not authorized")||r.error?.message?.includes("Not authorized")?console.error("\uD83D\uDD34 PROBLEM: Domain nicht verifiziert! Gehe zu https://resend.com/domains und verifiziere inclusions.zone"):r.error?.message?.includes("Invalid API key")||r.error?.statusCode===401?console.error("\uD83D\uDD34 PROBLEM: API Key ung\xfcltig! Pr\xfcfe RESEND_API_KEY in .env"):r.error?.message?.includes("domain")&&console.error("\uD83D\uDD34 PROBLEM: Domain-Problem! Pr\xfcfe Domain-Verifizierung in Resend Dashboard")}else console.log("✅ Newsletter Opt-In E-Mail gesendet:",r.data?.id)}catch(t){return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:285",message:"Exception in resend.emails.send",data:{error:t?.message,errorName:t?.name,errorStack:t?.stack,from:o,to:e},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H5"})}).catch(()=>{}),console.error("❌ Exception beim Senden der Newsletter Opt-In E-Mail:",t),{error:t?.message||String(t)}}return r}async function u(e,t){return s?await s.emails.send({from:o,to:e,subject:"Willkommen beim Inclusions Newsletter!",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ff00ff;">Willkommen, ${t}!</h1>
          <p>Du erh\xe4ltst jetzt die neuesten Infos zu unseren Events, exklusive Updates und wirst Teil einer Bewegung, die wirklich etwas bewegt.</p>
          <p>Bis bald,<br>Das Inclusions Team</p>
        </body>
      </html>
    `,text:`Willkommen, ${t}!

Du erh\xe4ltst jetzt die neuesten Infos zu unseren Events, exklusive Updates und wirst Teil einer Bewegung, die wirklich etwas bewegt.

Bis bald,
Das Inclusions Team`}):{error:"Resend nicht konfiguriert"}}async function p(e){if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:262",message:"sendNewsletterNotification called",data:{email:e.email,resendIsNull:null===s,fromEmail:o,adminEmail:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),!s)return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:274",message:"Resend is null - returning error",data:{email:e.email},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),{error:"Resend nicht konfiguriert"};let t=`📬 Newsletter-Anmeldung${e.firstName||e.lastName?`: ${[e.firstName,e.lastName].filter(Boolean).join(" ")}`:""} - Inclusions`,n=`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #ff00ff;">📬 Neue Newsletter-Anmeldung</h2>
        
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
          <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
          ${e.firstName?`<p><strong>Vorname:</strong> ${e.firstName}</p>`:""}
          ${e.lastName?`<p><strong>Nachname:</strong> ${e.lastName}</p>`:""}
          ${void 0!==e.hasDisability?`<p><strong>Menschen mit Beeintr\xe4chtigung:</strong> ${e.hasDisability?"Ja":"Nein"}</p>`:""}
        </div>

        ${e.interests&&e.interests.length>0?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Interessen</h3>
          <p>${e.interests.join(", ")}</p>
        </div>
        `:""}

        ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
        <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
          <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
          ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
          ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
          ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
          ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
        </div>
        `:""}
      </body>
    </html>
  `,r=`📬 Neue Newsletter-Anmeldung

Kontaktinformationen:
E-Mail: ${e.email}
${e.firstName?`Vorname: ${e.firstName}
`:""}${e.lastName?`Nachname: ${e.lastName}
`:""}${void 0!==e.hasDisability?`Menschen mit Beeintr\xe4chtigung: ${e.hasDisability?"Ja":"Nein"}
`:""}
${e.interests&&e.interests.length>0?`Interessen: ${e.interests.join(", ")}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,i=[];if(a)try{fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:321",message:"Sending notification email to admin",data:{from:o,to:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{});let e=await s.emails.send({from:o,to:a,subject:t,html:n,text:r});if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:330",message:"Notification email result",data:{hasError:!!e.error,error:e.error,errorMessage:e.error?.message,errorName:e.error?.name,errorStatusCode:e.error?.statusCode,hasData:!!e.data,emailId:e.data?.id,fullResult:JSON.stringify(e)},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{}),e.error){let t={error:e.error,message:e.error?.message,name:e.error?.name,statusCode:e.error?.statusCode,from:o,to:a};console.error(`❌ ${a} Fehler (Newsletter Notification):`,JSON.stringify(t,null,2)),e.error?.message?.includes("not authorized")||e.error?.message?.includes("Not authorized")?console.error("\uD83D\uDD34 PROBLEM: Domain nicht verifiziert! Gehe zu https://resend.com/domains und verifiziere inclusions.zone"):e.error?.message?.includes("Invalid API key")||e.error?.statusCode===401?console.error("\uD83D\uDD34 PROBLEM: API Key ung\xfcltig! Pr\xfcfe RESEND_API_KEY in .env"):e.error?.message?.includes("domain")&&console.error("\uD83D\uDD34 PROBLEM: Domain-Problem! Pr\xfcfe Domain-Verifizierung in Resend Dashboard")}else console.log(`✅ Newsletter-Benachrichtigung an ${a} gesendet`),i.push({email:a,id:e.data?.id})}catch(e){fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:337",message:"Exception sending notification email",data:{error:e instanceof Error?e.message:String(e)},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H5"})}).catch(()=>{}),console.error(`❌ Fehler beim Senden an ${a}:`,e)}if(0===i.length)try{let e=await s.emails.send({from:o,to:"roland.luthi@gmail.com",subject:t,html:n,text:r});e.error||(console.log("✅ Newsletter-Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback)"),i.push({email:"roland.luthi@gmail.com",id:e.data?.id}))}catch(e){console.error("❌ Fehler:",e)}return i.length>0?{id:i[0].id,data:{results:i}}:{error:"Keine E-Mails versendet"}}async function h(e,t,n,r){if(!s)return console.error("❌ Resend nicht konfiguriert in sendVIPConfirmation"),{error:"Resend nicht konfiguriert"};try{let i=t.split(" ")[0],l="";n&&r?l=`am ${n} bei Inclusions 2 im ${r}`:n?l=`am ${n}`:r&&(l=`bei Inclusions 2 im ${r}`),console.log(`📧 Sende VIP-Best\xe4tigung an: ${e}`);let d=await s.emails.send({from:o,to:e,reply_to:a,subject:"Ihre VIP-Anmeldung ist angekommen - Inclusions",html:`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.8; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; font-size: 16px;">
            <h1 style="color: #ff00ff; font-size: 24px; margin-bottom: 20px;">Liebe / Lieber ${i}</h1>
            <p style="font-size: 18px; margin-bottom: 15px;">vielen Dank f\xfcr deine Anmeldung. Wir freuen uns sehr, dass du${l?` ${l} dabei bist`:" dabei bist"}.</p>
            <p style="margin-bottom: 15px;">Falls es vorab noch Unklarheiten gibt, melden wir uns bei dir.</p>
            <p style="margin-bottom: 15px;">Kurz vor dem Event erh\xe4ltst du von uns alle wichtigen Infos zu Anreise, Einlass und Ablauf der Party.</p>
            <p style="margin-top: 30px;">Bis bald – wir freuen uns auf dich.</p>
            <p style="margin-top: 20px;">Herzlich<br>Dein Inclusions Team</p>
          </body>
        </html>
      `,text:`Liebe / Lieber ${i}

vielen Dank f\xfcr deine Anmeldung. Wir freuen uns sehr, dass du${l?` ${l} dabei bist`:" dabei bist"}.

Falls es vorab noch Unklarheiten gibt, melden wir uns bei dir.
Kurz vor dem Event erh\xe4ltst du von uns alle wichtigen Infos zu Anreise, Einlass und Ablauf der Party.

Bis bald – wir freuen uns auf dich.

Herzlich
Dein Inclusions Team`});if(d.error)return console.error("❌ Resend API Fehler:",d.error),{error:d.error};return console.log("✅ VIP-Best\xe4tigung gesendet, ID:",d.data?.id),{id:d.data?.id,data:d.data}}catch(e){return console.error("❌ Fehler beim Senden der VIP-Best\xe4tigung:",e),{error:e instanceof Error?e.message:"Unbekannter Fehler"}}}async function g(e){if(!s)return console.error("❌ Resend nicht konfiguriert in sendVIPNotification"),{error:"Resend nicht konfiguriert"};try{let t=`🎫 VIP-Anmeldung${e.eventDate?`: ${e.eventDate}`:""}${e.name?` - ${e.name}`:""} - Inclusions`,n=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #ff00ff;">🎫 Neue VIP-Anmeldung</h2>
          
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
            <p><strong>Name:</strong> ${e.name}</p>
            <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
            ${e.phone?`<p><strong>Telefon:</strong> <a href="tel:${e.phone}">${e.phone}</a></p>`:""}
            ${e.company?`<p><strong>Firma:</strong> ${e.company}</p>`:""}
          </div>

          ${e.eventDate||e.eventLocation||e.eventType||e.numberOfGuests||e.specialRequirements?`
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Event-Details</h3>
            ${e.eventDate?`<p><strong>Event-Datum:</strong> ${e.eventDate}</p>`:""}
            ${e.eventLocation?`<p><strong>Event-Ort:</strong> ${e.eventLocation}</p>`:""}
            ${e.eventType?`<p><strong>Event-Typ:</strong> ${e.eventType}</p>`:""}
            ${e.numberOfGuests?`<p><strong>Anzahl G\xe4ste:</strong> ${e.numberOfGuests}</p>`:""}
            ${e.specialRequirements?`<p><strong>Besondere Anforderungen:</strong><br>${e.specialRequirements.replace(/\n/g,"<br>")}</p>`:""}
          </div>
          `:""}

          ${e.message?`
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Nachricht</h3>
            <p style="white-space: pre-wrap;">${e.message.replace(/\n/g,"<br>")}</p>
          </div>
          `:""}

          ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
          <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
            <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
            ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
            ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
            ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
            ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
          </div>
          `:""}
        </body>
      </html>
    `,r=`🎫 Neue VIP-Anmeldung

Kontaktinformationen:
Name: ${e.name}
E-Mail: ${e.email}
${e.phone?`Telefon: ${e.phone}
`:""}${e.company?`Firma: ${e.company}
`:""}
${e.eventDate||e.eventLocation||e.eventType||e.numberOfGuests||e.specialRequirements?`Event-Details:
${e.eventDate?`Event-Datum: ${e.eventDate}
`:""}${e.eventLocation?`Event-Ort: ${e.eventLocation}
`:""}${e.eventType?`Event-Typ: ${e.eventType}
`:""}${e.numberOfGuests?`Anzahl G\xe4ste: ${e.numberOfGuests}
`:""}${e.specialRequirements?`Besondere Anforderungen: ${e.specialRequirements}
`:""}
`:""}${e.message?`Nachricht:
${e.message}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,i=[];if(a){console.log(`📧 Sende VIP-Benachrichtigung an: ${a}`);try{let l=await s.emails.send({from:o,to:a,reply_to:e.email,subject:t,html:n,text:r});l.error?console.warn(`⚠️ ${a} Fehler:`,l.error):(console.log(`✅ Benachrichtigung an ${a} gesendet, ID:`,l.data?.id),i.push({email:a,id:l.data?.id}))}catch(e){console.error(`❌ Fehler beim Senden an ${a}:`,e)}}if(0===i.length){console.log(`📧 Sende VIP-Benachrichtigung an: roland.luthi@gmail.com (Fallback)`);try{let a=await s.emails.send({from:o,to:"roland.luthi@gmail.com",reply_to:e.email,subject:t,html:n,text:r});a.error?console.error("❌ Fehler bei roland.luthi@gmail.com:",a.error):(console.log("✅ Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback), ID:",a.data?.id),i.push({email:"roland.luthi@gmail.com",id:a.data?.id}))}catch(e){console.error("❌ Fehler beim Senden an roland.luthi@gmail.com:",e)}}if(i.length>0)return{id:i[0].id,data:{results:i},success:!0};return{error:"Keine E-Mails konnten versendet werden"}}catch(e){return console.error("❌ Fehler beim Senden der VIP-Benachrichtigung:",e),{error:e instanceof Error?e.message:"Unbekannter Fehler"}}}fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:13",message:"Resend instance created",data:{resendIsNull:null===s,hasApiKey:!!i},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{})}};var t=require("../../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),r=t.X(0,[1638,6206,1788],()=>n(5442));module.exports=r})();