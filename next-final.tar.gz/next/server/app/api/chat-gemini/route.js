"use strict";(()=>{var e={};e.id=978,e.ids=[978],e.modules={517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},3956:(e,t,n)=>{n.r(t),n.d(t,{headerHooks:()=>el,originalPathname:()=>eu,patchFetch:()=>eh,requestAsyncStorage:()=>ea,routeModule:()=>eo,serverHooks:()=>ed,staticGenerationAsyncStorage:()=>er,staticGenerationBailout:()=>ec});var i,s,o,a,r,d,l,c,u,h,f,g,m={};n.r(m),n.d(m,{POST:()=>es,dynamic:()=>ei});var p=n(5419),E=n(9108),I=n(9678),b=n(8070);(function(e){e.STRING="string",e.NUMBER="number",e.INTEGER="integer",e.BOOLEAN="boolean",e.ARRAY="array",e.OBJECT="object"})(i||(i={})),function(e){e.LANGUAGE_UNSPECIFIED="language_unspecified",e.PYTHON="python"}(s||(s={})),function(e){e.OUTCOME_UNSPECIFIED="outcome_unspecified",e.OUTCOME_OK="outcome_ok",e.OUTCOME_FAILED="outcome_failed",e.OUTCOME_DEADLINE_EXCEEDED="outcome_deadline_exceeded"}(o||(o={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let C=["user","model","function","system"];(function(e){e.HARM_CATEGORY_UNSPECIFIED="HARM_CATEGORY_UNSPECIFIED",e.HARM_CATEGORY_HATE_SPEECH="HARM_CATEGORY_HATE_SPEECH",e.HARM_CATEGORY_SEXUALLY_EXPLICIT="HARM_CATEGORY_SEXUALLY_EXPLICIT",e.HARM_CATEGORY_HARASSMENT="HARM_CATEGORY_HARASSMENT",e.HARM_CATEGORY_DANGEROUS_CONTENT="HARM_CATEGORY_DANGEROUS_CONTENT",e.HARM_CATEGORY_CIVIC_INTEGRITY="HARM_CATEGORY_CIVIC_INTEGRITY"})(a||(a={})),function(e){e.HARM_BLOCK_THRESHOLD_UNSPECIFIED="HARM_BLOCK_THRESHOLD_UNSPECIFIED",e.BLOCK_LOW_AND_ABOVE="BLOCK_LOW_AND_ABOVE",e.BLOCK_MEDIUM_AND_ABOVE="BLOCK_MEDIUM_AND_ABOVE",e.BLOCK_ONLY_HIGH="BLOCK_ONLY_HIGH",e.BLOCK_NONE="BLOCK_NONE"}(r||(r={})),function(e){e.HARM_PROBABILITY_UNSPECIFIED="HARM_PROBABILITY_UNSPECIFIED",e.NEGLIGIBLE="NEGLIGIBLE",e.LOW="LOW",e.MEDIUM="MEDIUM",e.HIGH="HIGH"}(d||(d={})),function(e){e.BLOCKED_REASON_UNSPECIFIED="BLOCKED_REASON_UNSPECIFIED",e.SAFETY="SAFETY",e.OTHER="OTHER"}(l||(l={})),function(e){e.FINISH_REASON_UNSPECIFIED="FINISH_REASON_UNSPECIFIED",e.STOP="STOP",e.MAX_TOKENS="MAX_TOKENS",e.SAFETY="SAFETY",e.RECITATION="RECITATION",e.LANGUAGE="LANGUAGE",e.BLOCKLIST="BLOCKLIST",e.PROHIBITED_CONTENT="PROHIBITED_CONTENT",e.SPII="SPII",e.MALFORMED_FUNCTION_CALL="MALFORMED_FUNCTION_CALL",e.OTHER="OTHER"}(c||(c={})),function(e){e.TASK_TYPE_UNSPECIFIED="TASK_TYPE_UNSPECIFIED",e.RETRIEVAL_QUERY="RETRIEVAL_QUERY",e.RETRIEVAL_DOCUMENT="RETRIEVAL_DOCUMENT",e.SEMANTIC_SIMILARITY="SEMANTIC_SIMILARITY",e.CLASSIFICATION="CLASSIFICATION",e.CLUSTERING="CLUSTERING"}(u||(u={})),function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.AUTO="AUTO",e.ANY="ANY",e.NONE="NONE"}(h||(h={})),function(e){e.MODE_UNSPECIFIED="MODE_UNSPECIFIED",e.MODE_DYNAMIC="MODE_DYNAMIC"}(f||(f={}));/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y extends Error{constructor(e){super(`[GoogleGenerativeAI Error]: ${e}`)}}class v extends y{constructor(e,t){super(e),this.response=t}}class O extends y{constructor(e,t,n,i){super(e),this.status=t,this.statusText=n,this.errorDetails=i}}class T extends y{}class S extends y{}!function(e){e.GENERATE_CONTENT="generateContent",e.STREAM_GENERATE_CONTENT="streamGenerateContent",e.COUNT_TOKENS="countTokens",e.EMBED_CONTENT="embedContent",e.BATCH_EMBED_CONTENTS="batchEmbedContents"}(g||(g={}));class _{constructor(e,t,n,i,s){this.model=e,this.task=t,this.apiKey=n,this.stream=i,this.requestOptions=s}toString(){var e,t;let n=(null===(e=this.requestOptions)||void 0===e?void 0:e.apiVersion)||"v1beta",i=(null===(t=this.requestOptions)||void 0===t?void 0:t.baseUrl)||"https://generativelanguage.googleapis.com",s=`${i}/${n}/${this.model}:${this.task}`;return this.stream&&(s+="?alt=sse"),s}}async function A(e){var t;let n=new Headers;n.append("Content-Type","application/json"),n.append("x-goog-api-client",function(e){let t=[];return(null==e?void 0:e.apiClient)&&t.push(e.apiClient),t.push("genai-js/0.24.1"),t.join(" ")}(e.requestOptions)),n.append("x-goog-api-key",e.apiKey);let i=null===(t=e.requestOptions)||void 0===t?void 0:t.customHeaders;if(i){if(!(i instanceof Headers))try{i=new Headers(i)}catch(e){throw new T(`unable to convert customHeaders value ${JSON.stringify(i)} to Headers: ${e.message}`)}for(let[e,t]of i.entries()){if("x-goog-api-key"===e)throw new T(`Cannot set reserved header name ${e}`);if("x-goog-api-client"===e)throw new T(`Header name ${e} can only be set using the apiClient field`);n.append(e,t)}}return n}async function N(e,t,n,i,s,o){let a=new _(e,t,n,i,o);return{url:a.toString(),fetchOptions:Object.assign(Object.assign({},function(e){let t={};if((null==e?void 0:e.signal)!==void 0||(null==e?void 0:e.timeout)>=0){let n=new AbortController;(null==e?void 0:e.timeout)>=0&&setTimeout(()=>n.abort(),e.timeout),(null==e?void 0:e.signal)&&e.signal.addEventListener("abort",()=>{n.abort()}),t.signal=n.signal}return t}(o)),{method:"POST",headers:await A(a),body:s})}}async function w(e,t,n,i,s,o={},a=fetch){let{url:r,fetchOptions:d}=await N(e,t,n,i,s,o);return R(r,d,a)}async function R(e,t,n=fetch){let i;try{i=await n(e,t)}catch(t){(function(e,t){let n=e;throw"AbortError"===n.name?(n=new S(`Request aborted when fetching ${t.toString()}: ${e.message}`)).stack=e.stack:e instanceof O||e instanceof T||((n=new y(`Error fetching from ${t.toString()}: ${e.message}`)).stack=e.stack),n})(t,e)}return i.ok||await D(i,e),i}async function D(e,t){let n,i="";try{let t=await e.json();i=t.error.message,t.error.details&&(i+=` ${JSON.stringify(t.error.details)}`,n=t.error.details)}catch(e){}throw new O(`Error fetching from ${t.toString()}: [${e.status} ${e.statusText}] ${i}`,e.status,e.statusText,n)}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function k(e){return e.text=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning text from the first candidate only. Access response.candidates directly to use the other candidates.`),j(e.candidates[0]))throw new v(`${P(e)}`,e);return function(e){var t,n,i,s;let o=[];if(null===(n=null===(t=e.candidates)||void 0===t?void 0:t[0].content)||void 0===n?void 0:n.parts)for(let t of null===(s=null===(i=e.candidates)||void 0===i?void 0:i[0].content)||void 0===s?void 0:s.parts)t.text&&o.push(t.text),t.executableCode&&o.push("\n```"+t.executableCode.language+"\n"+t.executableCode.code+"\n```\n"),t.codeExecutionResult&&o.push("\n```\n"+t.codeExecutionResult.output+"\n```\n");return o.length>0?o.join(""):""}(e)}if(e.promptFeedback)throw new v(`Text not available. ${P(e)}`,e);return""},e.functionCall=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),j(e.candidates[0]))throw new v(`${P(e)}`,e);return console.warn("response.functionCall() is deprecated. Use response.functionCalls() instead."),x(e)[0]}if(e.promptFeedback)throw new v(`Function call not available. ${P(e)}`,e)},e.functionCalls=()=>{if(e.candidates&&e.candidates.length>0){if(e.candidates.length>1&&console.warn(`This response had ${e.candidates.length} candidates. Returning function calls from the first candidate only. Access response.candidates directly to use the other candidates.`),j(e.candidates[0]))throw new v(`${P(e)}`,e);return x(e)}if(e.promptFeedback)throw new v(`Function call not available. ${P(e)}`,e)},e}function x(e){var t,n,i,s;let o=[];if(null===(n=null===(t=e.candidates)||void 0===t?void 0:t[0].content)||void 0===n?void 0:n.parts)for(let t of null===(s=null===(i=e.candidates)||void 0===i?void 0:i[0].content)||void 0===s?void 0:s.parts)t.functionCall&&o.push(t.functionCall);return o.length>0?o:void 0}let M=[c.RECITATION,c.SAFETY,c.LANGUAGE];function j(e){return!!e.finishReason&&M.includes(e.finishReason)}function P(e){var t,n,i;let s="";if((!e.candidates||0===e.candidates.length)&&e.promptFeedback)s+="Response was blocked",(null===(t=e.promptFeedback)||void 0===t?void 0:t.blockReason)&&(s+=` due to ${e.promptFeedback.blockReason}`),(null===(n=e.promptFeedback)||void 0===n?void 0:n.blockReasonMessage)&&(s+=`: ${e.promptFeedback.blockReasonMessage}`);else if(null===(i=e.candidates)||void 0===i?void 0:i[0]){let t=e.candidates[0];j(t)&&(s+=`Candidate was blocked due to ${t.finishReason}`,t.finishMessage&&(s+=`: ${t.finishMessage}`))}return s}function L(e){return this instanceof L?(this.v=e,this):new L(e)}"function"==typeof SuppressedError&&SuppressedError;/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let F=/^data\: (.*)(?:\n\n|\r\r|\r\n\r\n)/;async function G(e){let t=[],n=e.getReader();for(;;){let{done:e,value:i}=await n.read();if(e)return k(function(e){let t=e[e.length-1],n={promptFeedback:null==t?void 0:t.promptFeedback};for(let t of e){if(t.candidates){let e=0;for(let i of t.candidates)if(n.candidates||(n.candidates=[]),n.candidates[e]||(n.candidates[e]={index:e}),n.candidates[e].citationMetadata=i.citationMetadata,n.candidates[e].groundingMetadata=i.groundingMetadata,n.candidates[e].finishReason=i.finishReason,n.candidates[e].finishMessage=i.finishMessage,n.candidates[e].safetyRatings=i.safetyRatings,i.content&&i.content.parts){n.candidates[e].content||(n.candidates[e].content={role:i.content.role||"user",parts:[]});let t={};for(let s of i.content.parts)s.text&&(t.text=s.text),s.functionCall&&(t.functionCall=s.functionCall),s.executableCode&&(t.executableCode=s.executableCode),s.codeExecutionResult&&(t.codeExecutionResult=s.codeExecutionResult),0===Object.keys(t).length&&(t.text=""),n.candidates[e].content.parts.push(t)}e++}t.usageMetadata&&(n.usageMetadata=t.usageMetadata)}return n}(t));t.push(i)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function H(e,t,n,i){return function(e){let[t,n]=(function(e){let t=e.getReader();return new ReadableStream({start(e){let n="";return function i(){return t.read().then(({value:t,done:s})=>{let o;if(s){if(n.trim()){e.error(new y("Failed to parse stream"));return}e.close();return}let a=(n+=t).match(F);for(;a;){try{o=JSON.parse(a[1])}catch(t){e.error(new y(`Error parsing JSON response: "${a[1]}"`));return}e.enqueue(o),a=(n=n.substring(a[0].length)).match(F)}return i()}).catch(e=>{let t=e;throw t.stack=e.stack,t="AbortError"===t.name?new S("Request aborted when reading from the stream"):new y("Error reading from the stream")})}()}})})(e.body.pipeThrough(new TextDecoderStream("utf8",{fatal:!0}))).tee();return{stream:function(e){return function(e,t,n){if(!Symbol.asyncIterator)throw TypeError("Symbol.asyncIterator is not defined.");var i,s=n.apply(e,t||[]),o=[];return i={},a("next"),a("throw"),a("return"),i[Symbol.asyncIterator]=function(){return this},i;function a(e){s[e]&&(i[e]=function(t){return new Promise(function(n,i){o.push([e,t,n,i])>1||r(e,t)})})}function r(e,t){try{var n;(n=s[e](t)).value instanceof L?Promise.resolve(n.value.v).then(d,l):c(o[0][2],n)}catch(e){c(o[0][3],e)}}function d(e){r("next",e)}function l(e){r("throw",e)}function c(e,t){e(t),o.shift(),o.length&&r(o[0][0],o[0][1])}}(this,arguments,function*(){let t=e.getReader();for(;;){let{value:e,done:n}=yield L(t.read());if(n)break;yield yield L(k(e))}})}(t),response:G(n)}}(await w(t,g.STREAM_GENERATE_CONTENT,e,!0,JSON.stringify(n),i))}async function B(e,t,n,i){let s=await w(t,g.GENERATE_CONTENT,e,!1,JSON.stringify(n),i);return{response:k(await s.json())}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $(e){if(null!=e){if("string"==typeof e)return{role:"system",parts:[{text:e}]};if(e.text)return{role:"system",parts:[e]};if(e.parts)return e.role?e:{role:"system",parts:e.parts}}}function K(e){let t=[];if("string"==typeof e)t=[{text:e}];else for(let n of e)"string"==typeof n?t.push({text:n}):t.push(n);return function(e){let t={role:"user",parts:[]},n={role:"function",parts:[]},i=!1,s=!1;for(let o of e)"functionResponse"in o?(n.parts.push(o),s=!0):(t.parts.push(o),i=!0);if(i&&s)throw new y("Within a single message, FunctionResponse cannot be mixed with other type of part in the request for sending chat message.");if(!i&&!s)throw new y("No content is provided for sending chat message.");return i?t:n}(t)}function U(e){let t;return t=e.contents?e:{contents:[K(e)]},e.systemInstruction&&(t.systemInstruction=$(e.systemInstruction)),t}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let J=["text","inlineData","functionCall","functionResponse","executableCode","codeExecutionResult"],Y={user:["text","inlineData"],function:["functionResponse"],model:["text","functionCall","executableCode","codeExecutionResult"],system:["text"]};function z(e){var t;if(void 0===e.candidates||0===e.candidates.length)return!1;let n=null===(t=e.candidates[0])||void 0===t?void 0:t.content;if(void 0===n||void 0===n.parts||0===n.parts.length)return!1;for(let e of n.parts)if(void 0===e||0===Object.keys(e).length||void 0!==e.text&&""===e.text)return!1;return!0}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let W="SILENT_ERROR";class q{constructor(e,t,n,i={}){this.model=t,this.params=n,this._requestOptions=i,this._history=[],this._sendPromise=Promise.resolve(),this._apiKey=e,(null==n?void 0:n.history)&&(function(e){let t=!1;for(let n of e){let{role:e,parts:i}=n;if(!t&&"user"!==e)throw new y(`First content should be with role 'user', got ${e}`);if(!C.includes(e))throw new y(`Each item should include role field. Got ${e} but valid roles are: ${JSON.stringify(C)}`);if(!Array.isArray(i))throw new y("Content should have 'parts' property with an array of Parts");if(0===i.length)throw new y("Each Content should have at least one part");let s={text:0,inlineData:0,functionCall:0,functionResponse:0,fileData:0,executableCode:0,codeExecutionResult:0};for(let e of i)for(let t of J)t in e&&(s[t]+=1);let o=Y[e];for(let t of J)if(!o.includes(t)&&s[t]>0)throw new y(`Content with role '${e}' can't contain '${t}' part`);t=!0}}(n.history),this._history=n.history)}async getHistory(){return await this._sendPromise,this._history}async sendMessage(e,t={}){var n,i,s,o,a,r;let d;await this._sendPromise;let l=K(e),c={safetySettings:null===(n=this.params)||void 0===n?void 0:n.safetySettings,generationConfig:null===(i=this.params)||void 0===i?void 0:i.generationConfig,tools:null===(s=this.params)||void 0===s?void 0:s.tools,toolConfig:null===(o=this.params)||void 0===o?void 0:o.toolConfig,systemInstruction:null===(a=this.params)||void 0===a?void 0:a.systemInstruction,cachedContent:null===(r=this.params)||void 0===r?void 0:r.cachedContent,contents:[...this._history,l]},u=Object.assign(Object.assign({},this._requestOptions),t);return this._sendPromise=this._sendPromise.then(()=>B(this._apiKey,this.model,c,u)).then(e=>{var t;if(z(e.response)){this._history.push(l);let n=Object.assign({parts:[],role:"model"},null===(t=e.response.candidates)||void 0===t?void 0:t[0].content);this._history.push(n)}else{let t=P(e.response);t&&console.warn(`sendMessage() was unsuccessful. ${t}. Inspect response object for details.`)}d=e}).catch(e=>{throw this._sendPromise=Promise.resolve(),e}),await this._sendPromise,d}async sendMessageStream(e,t={}){var n,i,s,o,a,r;await this._sendPromise;let d=K(e),l={safetySettings:null===(n=this.params)||void 0===n?void 0:n.safetySettings,generationConfig:null===(i=this.params)||void 0===i?void 0:i.generationConfig,tools:null===(s=this.params)||void 0===s?void 0:s.tools,toolConfig:null===(o=this.params)||void 0===o?void 0:o.toolConfig,systemInstruction:null===(a=this.params)||void 0===a?void 0:a.systemInstruction,cachedContent:null===(r=this.params)||void 0===r?void 0:r.cachedContent,contents:[...this._history,d]},c=Object.assign(Object.assign({},this._requestOptions),t),u=H(this._apiKey,this.model,l,c);return this._sendPromise=this._sendPromise.then(()=>u).catch(e=>{throw Error(W)}).then(e=>e.response).then(e=>{if(z(e)){this._history.push(d);let t=Object.assign({},e.candidates[0].content);t.role||(t.role="model"),this._history.push(t)}else{let t=P(e);t&&console.warn(`sendMessageStream() was unsuccessful. ${t}. Inspect response object for details.`)}}).catch(e=>{e.message!==W&&console.error(e)}),u}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function V(e,t,n,i){return(await w(t,g.COUNT_TOKENS,e,!1,JSON.stringify(n),i)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Z(e,t,n,i){return(await w(t,g.EMBED_CONTENT,e,!1,JSON.stringify(n),i)).json()}async function X(e,t,n,i){let s=n.requests.map(e=>Object.assign(Object.assign({},e),{model:t}));return(await w(t,g.BATCH_EMBED_CONTENTS,e,!1,JSON.stringify({requests:s}),i)).json()}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class Q{constructor(e,t,n={}){this.apiKey=e,this._requestOptions=n,t.model.includes("/")?this.model=t.model:this.model=`models/${t.model}`,this.generationConfig=t.generationConfig||{},this.safetySettings=t.safetySettings||[],this.tools=t.tools,this.toolConfig=t.toolConfig,this.systemInstruction=$(t.systemInstruction),this.cachedContent=t.cachedContent}async generateContent(e,t={}){var n;let i=U(e),s=Object.assign(Object.assign({},this._requestOptions),t);return B(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null===(n=this.cachedContent)||void 0===n?void 0:n.name},i),s)}async generateContentStream(e,t={}){var n;let i=U(e),s=Object.assign(Object.assign({},this._requestOptions),t);return H(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null===(n=this.cachedContent)||void 0===n?void 0:n.name},i),s)}startChat(e){var t;return new q(this.apiKey,this.model,Object.assign({generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:null===(t=this.cachedContent)||void 0===t?void 0:t.name},e),this._requestOptions)}async countTokens(e,t={}){let n=function(e,t){var n;let i={model:null==t?void 0:t.model,generationConfig:null==t?void 0:t.generationConfig,safetySettings:null==t?void 0:t.safetySettings,tools:null==t?void 0:t.tools,toolConfig:null==t?void 0:t.toolConfig,systemInstruction:null==t?void 0:t.systemInstruction,cachedContent:null===(n=null==t?void 0:t.cachedContent)||void 0===n?void 0:n.name,contents:[]},s=null!=e.generateContentRequest;if(e.contents){if(s)throw new T("CountTokensRequest must have one of contents or generateContentRequest, not both.");i.contents=e.contents}else if(s)i=Object.assign(Object.assign({},i),e.generateContentRequest);else{let t=K(e);i.contents=[t]}return{generateContentRequest:i}}(e,{model:this.model,generationConfig:this.generationConfig,safetySettings:this.safetySettings,tools:this.tools,toolConfig:this.toolConfig,systemInstruction:this.systemInstruction,cachedContent:this.cachedContent}),i=Object.assign(Object.assign({},this._requestOptions),t);return V(this.apiKey,this.model,n,i)}async embedContent(e,t={}){let n="string"==typeof e||Array.isArray(e)?{content:K(e)}:e,i=Object.assign(Object.assign({},this._requestOptions),t);return Z(this.apiKey,this.model,n,i)}async batchEmbedContents(e,t={}){let n=Object.assign(Object.assign({},this._requestOptions),t);return X(this.apiKey,this.model,e,n)}}/**
 * @license
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ee{constructor(e){this.apiKey=e}getGenerativeModel(e,t){if(!e.model)throw new y("Must provide a model name. Example: genai.getGenerativeModel({ model: 'my-model-name' })");return new Q(this.apiKey,e,t)}getGenerativeModelFromCachedContent(e,t,n){if(!e.name)throw new T("Cached content must contain a `name` field.");if(!e.model)throw new T("Cached content must contain a `model` field.");for(let n of["model","systemInstruction"])if((null==t?void 0:t[n])&&e[n]&&(null==t?void 0:t[n])!==e[n]){if("model"===n&&(t.model.startsWith("models/")?t.model.replace("models/",""):t.model)===(e.model.startsWith("models/")?e.model.replace("models/",""):e.model))continue;throw new T(`Different value for "${n}" specified in modelParams (${t[n]}) and cachedContent (${e[n]})`)}let i=Object.assign(Object.assign({},t),{model:e.model,tools:e.tools,toolConfig:e.toolConfig,systemInstruction:e.systemInstruction,cachedContent:e});return new Q(this.apiKey,i,n)}}var et=n(7543),en=n(6376);let ei="force-dynamic";async function es(e){let t=process.env.GEMINI_API_KEY;if(!t)return b.Z.json({error:"GEMINI_API_KEY ist nicht konfiguriert"},{status:500});let n=new ee(t).getGenerativeModel({model:"gemini-2.5-flash"});try{let t=await e.json(),i=t?.message??"";if(!i||""===i.trim())return b.Z.json({error:"Keine Nachricht erhalten"},{status:400});let s=function(){let e=(0,et.IP)(),t=(0,et.CP)(),n=(0,en.e3)(),i=(0,en.w0)();(0,en.J9)();let s="=== INCLUSIONS WEBSITE INFORMATIONEN ===\n\n";s+="EVENTS:\n",t.length>0&&(s+="Kommende Events:\n",t.forEach(e=>{s+=`- ${e.name}: ${(0,et.p6)(e.date)} in ${e.location}. ${e.description}
`,e.lineup&&e.lineup.length>0&&(s+=`  Line-up: ${e.lineup.join(", ")}
`)}));let o=e.filter(e=>"past"===e.status);return o.length>0&&(s+="\nVergangene Events:\n",o.slice(0,3).forEach(e=>{s+=`- ${e.name}: ${(0,et.p6)(e.date)} in ${e.location}. ${e.description}
`})),s+="\n\nDJS:\n",n.forEach(e=>{s+=`- ${e.name}`,e.text&&"Infos folgen"!==e.text&&(s+=`: ${e.text.substring(0,100)}${e.text.length>100?"...":""}`),e.hasDisability&&(s+=" (Inklusiver DJ)"),e.bookableIndividually&&(s+=" (Einzeln buchbar)"),s+="\n"}),i.length>0&&(s+="\nDJ PAIRS:\n",i.forEach(e=>{s+=`- ${e.name}`,e.text&&(s+=`: ${e.text}`),s+="\n"})),s+="\n\nALLGEMEINE INFORMATIONEN:\n- INCLUSIONS ist ein inklusives Event-Format\n- Menschen mit und ohne Beeintr\xe4chtigung feiern gemeinsam\n- Es gibt DJ's, Dance Crew und Events\n- Events finden meist im Supermarket Z\xfcrich statt\n- DJ's k\xf6nnen einzeln oder als Pairs gebucht werden\n\n\nANMELDUNG, TICKETS und WIE DABEI SEIN (f\xfcr Fragen wie: Wie kann ich mich anmelden? Wie melde ich mich an? Wie komme ich zur Party?):\n- Es gibt zwei Wege:\n  1) VIP (gratis): Wer IV-Ausweis, Beeintr\xe4chtigung oder Behinderung hat: Gratis Eintritt. Anmeldung vorher auf der Webseite unter VIP-Anmeldung n\xf6tig (Seite: anmeldung/vip). Mindestens 20 Jahre. Anmeldung im Vorfeld ist Pflicht. Betreuer:in nur gratis bei 1-zu-1 Betreuung. Freunde und Familie kaufen ein Ticket. TIXI-Taxi kann bei der VIP-Anmeldung angefragt werden. VIP-Vorteile: barrierefreier Club, Helfer-Team, verg\xfcnstigtes Essen und Trinken.\n  2) Party People / G\xe4ste: Ticket kaufen bei Supermarket (supermarket.li/events/inclusions/).\n- DJ's buchen: Auf der Webseite unter DJ's oder Booking (djs, booking).\n- Dance Crew buchen: Auf der Webseite unter Dance Crew (dance-crew).\n- Spenden: Auf der Webseite unter Spenden (spenden). TWINT m\xf6glich.\n- Newsletter: Auf der Webseite unter Newsletter anmelden.\n"}(),o=`
Du bist ein freundlicher Voice-Assistent f\xfcr Menschen mit verschiedenen Beeintr\xe4chtigungen (kognitive, sprachliche, sensorische).

WICHTIGE REGELN f\xfcr deine Antworten:
1. Sprache: Sehr einfaches Deutsch, wie zu einem guten Freund
2. L\xe4nge: Maximal 2-3 kurze S\xe4tze (nicht mehr als 20 W\xf6rter insgesamt)
3. W\xf6rter: Nur einfache, bekannte W\xf6rter. Keine Fremdw\xf6rter, keine Fachbegriffe
4. Struktur: Ein Gedanke pro Satz. Klare, direkte Aussagen
5. Ton: Freundlich, ermutigend, geduldig. Keine komplizierten Erkl\xe4rungen
6. Beispiele: Wenn n\xf6tig, ein einfaches Beispiel geben
7. Daten: Nutze NUR die Informationen aus dem Kontext unten. Erfinde nichts!
8. Bei Fragen wie "Wie kann ich mich anmelden?", "Wie melde ich mich an?": Zuerst die zwei Wege nennen (VIP auf der Webseite / Ticket bei Supermarket). Kurz und klar.

Wenn du die Frage nicht verstehst oder die Information nicht im Kontext steht, sage einfach: "Das habe ich nicht verstanden. Kannst du es anders sagen?" oder "Das wei\xdf ich leider nicht."

=== KONTEXT: WEBSITE-DATEN ===
${s}
=== ENDE KONTEXT ===

Nutzer sagt: "${i}"

Antworte jetzt in sehr einfacher Sprache basierend auf den Informationen aus dem Kontext:
`,a=(await n.generateContent(o)).response.text();if(!a)return b.Z.json({error:"Keine Antwort von Gemini erhalten"},{status:500});return b.Z.json({reply:a})}catch(t){console.error("Gemini API Fehler:",t);let e=t?.message||"Unbekannter Fehler";if(JSON.stringify(t,null,2),e.includes("403")||e.includes("API key")||e.includes("API_KEY"))return b.Z.json({error:"API-Key Problem",details:"Der API-Key ist ung\xfcltig oder gesperrt. Bitte erstelle einen neuen API-Key in Google AI Studio.",debug:void 0},{status:500});if(e.includes("fetch")||e.includes("network"))return b.Z.json({error:"Verbindungsfehler",details:"Fehler beim Verbinden zur Gemini API. Bitte pr\xfcfe deine Internetverbindung.",debug:void 0},{status:500});return b.Z.json({error:"Fehler beim Aufruf von Gemini",details:e,debug:void 0},{status:500})}}let eo=new p.AppRouteRouteModule({definition:{kind:E.x.APP_ROUTE,page:"/api/chat-gemini/route",pathname:"/api/chat-gemini",filename:"route",bundlePath:"app/api/chat-gemini/route"},resolvedPagePath:"/Users/roland/Curser/inclusions-2.0/app/api/chat-gemini/route.ts",nextConfigOutput:"",userland:m}),{requestAsyncStorage:ea,staticGenerationAsyncStorage:er,serverHooks:ed,headerHooks:el,staticGenerationBailout:ec}=eo,eu="/api/chat-gemini/route";function eh(){return(0,I.patchFetch)({serverHooks:ed,staticGenerationAsyncStorage:er})}},6376:(e,t,n)=>{n.d(t,{w0:()=>r,e3:()=>s,J9:()=>a,Xu:()=>o,Fb:()=>l,wx:()=>c,OF:()=>u});let i=JSON.parse('{"djs":[{"id":"samy-jackson","name":"Samy Jackson","image":"/images/samy-jackson.png","text":"Treibende elektronische Beats mit Tiefe und Haltung. Samy Jackson verbindet Clubkultur, Energie und Offenheit auf dem Dancefloor.","soundcloud":"https://soundcloud.com/animaltrainer","hasDisability":false,"bookableIndividually":true},{"id":"dj-baechli","name":"DJ B\xe4chli","image":"/images/djbaechli.png","text":"Infos folgen","hasDisability":true,"bookableIndividually":false},{"id":"hoibaer","name":"Hoibaer","image":"/images/hoibaer.png","text":"Teil des Inclusions DJ-Pools mit Herz und Seele. Hoibaer bringt W\xe4rme, Groove und echtes Inclusions-Feeling auf die Tanzfl\xe4che.","soundcloud":"https://soundcloud.com/hoibaer","hasDisability":false,"bookableIndividually":true},{"id":"jerry","name":"Jerry","image":"/images/dj-Jerry.jpg","text":"Infos folgen","hasDisability":true,"bookableIndividually":false},{"id":"miniart","name":"_miniArt\xb0\xb0\xb0","image":"/images/miniart.png","text":"Z\xfcrcher DJ und Teil des Inclusions DJ-Pools. Mit feinem Gesp\xfcr und klaren Sounds schafft _miniArt\xb0\xb0\xb0 verbindende Momente.","soundcloud":"https://soundcloud.com/user214016831","hasDisability":false,"bookableIndividually":true},{"id":"sarita","name":"Sarita","image":"/images/DJ-Sarita.jpg","text":"Infos folgen","hasDisability":true,"bookableIndividually":false},{"id":"zagara","name":"Zagara","image":"/images/zagara.png","text":"Vielschichtige Sounds, hypnotische Grooves und Emotion. Zagara nimmt dich mit auf eine musikalische Reise nach innen.","soundcloud":"https://soundcloud.com/zagara-1","hasDisability":false,"bookableIndividually":true},{"id":"coco-bewegt","name":"Coco.bewegt","image":"/images/coco-bewegt.png","text":"Elektronische Musik mit Gef\xfchl, Tiefe und Bewegung. coco.bewegt gestaltet Sets, die ber\xfchren und Raum zum Loslassen schaffen.","soundcloud":"https://soundcloud.com/coco-bewegt","hasDisability":false,"bookableIndividually":true},{"id":"sandro","name":"Sandro","text":"Infos folgen","hasDisability":true,"bookableIndividually":false},{"id":"ashan","name":"Ashan","image":"/images/ashan-live.jpg","text":"Ashan spielt live. Seine World Beats zaubern ein L\xe4cheln auf die Gesichter – und ehe du es merkst, tanzt du schon mit.","hasDisability":false,"bookableIndividually":true}],"pairs":[{"id":"samy-jackson-dj-baechli","name":"Samy Jackson & DJ B\xe4chli","dj1Id":"samy-jackson","dj2Id":"dj-baechli","text":"Samy und Fabian waren das Premieren-Duo der Inclusions 1. Sie haben die Tanzfl\xe4che zum Beben gebracht – beim n\xe4chsten Mal auf keinen Fall verpassen!","image":"/images/samy-jackson-dj-baechli.png"},{"id":"hoibaer-jerry","name":"Hoibaer & Jerry","dj1Id":"hoibaer","dj2Id":"jerry","text":"Hier haben sich zwei gesucht und gefunden. Schon beim ersten Training im Studio hat die Chemie perfekt gestimmt. Man darf gespannt sein, was die beiden als N\xe4chstes abliefern.","image":"/images/hoibaer-jerry.png"},{"id":"miniart-sarita","name":"_miniArt\xb0\xb0\xb0 & Sarita","dj1Id":"miniart","dj2Id":"sarita","text":"Sara liebt die B\xfchne, und das Publikum liebt ihre Energie. Zusammen mit Reto verbreiten sie pure Lebensfreude und jede Menge Spass.","image":"/images/miniart-sarita.png"},{"id":"zagara-sandro","name":"Zagara","dj1Id":"zagara","dj2Id":"sandro","text":"Die beiden haben erst an der Inclusions 1 zueinandergefunden. Wir sind gespannt, wie diese neue Connection den Dancefloor k\xfcnftig erobern wird.","image":"/images/zagara-sandro.png"}]}');function s(){return i.djs}function o(e){return i.djs.find(t=>t.id===e)}function a(){return i.djs.filter(e=>e.bookableIndividually)}function r(){return i.pairs}function d(e){return i.pairs.find(t=>t.id===e)}function l(e){let t=d(e);if(!t)return;let n=o(t.dj1Id),i=o(t.dj2Id);if(n&&i)return{...t,dj1:n,dj2:i}}function c(e){let t=[];for(let n of e){let e=o(n);if(e){t.push({type:"dj",data:e});continue}let i=d(n);i&&t.push({type:"pair",data:i})}return t}function u(e){let t=l(e);if(t)return`${t.dj1.name} & ${t.dj2.name}`}},7543:(e,t,n)=>{n.d(t,{p6:()=>r,IP:()=>s,jY:()=>a,CP:()=>o});let i=JSON.parse('{"events":[{"id":"inclusions-2nd-edition","name":"Inclusions 2","date":"2026-04-25","location":"Supermarket Z\xfcrich","description":"Wir feiern wieder gemeinsam – mit DJs, Dance Crew und vielen Begegnungen. Die Profi DJ\'s werden zusammen mit Inclusions DJ\'s (Menschen mit Beeintr\xe4chtigung) auflegen. Die Inclusions DJ\'s werden von den Resident DJ\'s gecoached.","lineup":["samy-jackson-dj-baechli","hoibaer-jerry","miniart-sarita","zagara","coco-bewegt"],"status":"upcoming","video":"/videos/next-event.mp4"},{"id":"inclusions-3rd-edition","name":"Inclusions 3","date":"2026-10-03","location":"Supermarket Z\xfcrich","description":"Weitere Details folgen in K\xfcrze.","status":"upcoming"},{"id":"inclusions-1st-edition","name":"Inclusions 1. Edition","date":"2025-09-27","location":"Supermarket Z\xfcrich","description":"\xdcber 400 Menschen – mit und ohne Beeintr\xe4chtigung – tanzten zusammen. Energie. Verbindung. Menschlichkeit. Pure Freude.","lineup":["samy-jackson-dj-baechli","hoibaer-jerry","miniart-sarita","zagara","coco-bewegt"],"status":"past"}]}');function s(){return i.events}function o(){return i.events.filter(e=>"upcoming"===e.status)}function a(){return i.events.filter(e=>"past"===e.status)}function r(e){return new Date(e).toLocaleDateString("de-CH",{day:"numeric",month:"long",year:"numeric"})}}};var t=require("../../../webpack-runtime.js");t.C(e);var n=e=>t(t.s=e),i=t.X(0,[1638,6206],()=>n(3956));module.exports=i})();