"use strict";exports.id=2913,exports.ids=[2913],exports.modules={42913:(e,n,t)=>{t.d(n,{Lf:()=>m,QO:()=>c,adminEmail:()=>a,dc:()=>u,fromEmail:()=>o,jJ:()=>d,resend:()=>s,resendApiKey:()=>i,sendVIPConfirmation:()=>p,sendVIPNotification:()=>g,wg:()=>l});var r=t(61788);let i=process.env.RESEND_API_KEY,o=process.env.RESEND_FROM_EMAIL||"noreply@inclusions.zone",a=process.env.RESEND_ADMIN_EMAIL||"info@inclusions.zone";fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:3",message:"Resend init - checking env vars",data:{hasApiKey:!!i,apiKeyPrefix:i?.substring(0,10)||"none",fromEmail:o,adminEmail:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),i&&"re_your-resend-api-key-here"!==i||(console.warn("⚠️ RESEND_API_KEY ist nicht gesetzt oder ist ein Platzhalter. E-Mail-Versand wird nicht funktionieren."),console.warn("⚠️ Formulare funktionieren trotzdem, aber keine E-Mails werden versendet."),fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:10",message:"RESEND_API_KEY missing or placeholder",data:{resendApiKey:i||"undefined"},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}));let s=i&&"re_your-resend-api-key-here"!==i?new r.R(i):null;async function l(e,n){if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:18",message:"sendContactConfirmation called",data:{to:e,name:n,resendIsNull:null===s,fromEmail:o},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),!s)return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:20",message:"Resend is null - returning error",data:{to:e,name:n},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),{error:"Resend nicht konfiguriert"};fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:22",message:"Calling resend.emails.send for contact confirmation",data:{from:o,to:e},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{});let t=await s.emails.send({from:o,to:e,subject:"Vielen Dank f\xfcr deine Anfrage - Inclusions",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #ff00ff;">Vielen Dank, ${n}!</h1>
          <p>Wir haben deine Anfrage erhalten und melden uns bald bei dir.</p>
          <p>Bis dahin,<br>Das Inclusions Team</p>
        </body>
      </html>
    `,text:`Vielen Dank, ${n}!

Wir haben deine Anfrage erhalten und melden uns bald bei dir.

Bis dahin,
Das Inclusions Team`});return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:41",message:"Contact confirmation email result",data:{hasError:!!t.error,error:t.error,hasData:!!t.data,emailId:t.data?.id},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{}),t}async function d(e,n,t,r,i){if(!s)return{error:"Resend nicht konfiguriert"};let l=n.split(" ")[0];return await s.emails.send({from:o,to:e,reply_to:a,subject:"Herzlichen Dank f\xfcr deine Anfrage - Inclusions",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.8; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; font-size: 16px;">
          <h1 style="color: #ff00ff; font-size: 24px; margin-bottom: 20px;">Liebe / Lieber ${l}</h1>
          <p style="font-size: 18px; margin-bottom: 15px;">Herzlichen Dank f\xfcr deine Anfrage.</p>
          <p style="margin-bottom: 15px;">Wir werden uns bald bei dir melden.</p>
          <p style="margin-top: 30px;">Bis bald,<br>Dein Inclusions Team</p>
        </body>
      </html>
    `,text:`Liebe / Lieber ${l}

Herzlichen Dank f\xfcr deine Anfrage.

Wir werden uns bald bei dir melden.

Bis bald,
Dein Inclusions Team`})}async function m(e){if(!s)return{error:"Resend nicht konfiguriert"};let n=e.bookingType||e.bookingItem?"Buchungsanfrage":"Kontaktanfrage",t=`📧 ${n}${e.bookingItem?`: ${e.bookingItem}`:""}${e.eventDate?` - ${e.eventDate}`:""} - Inclusions`,r=`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #ff00ff;">Neue ${n}</h2>
        
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
          <p><strong>Name:</strong> ${e.name}</p>
          <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
          ${e.phone?`<p><strong>Telefon:</strong> <a href="tel:${e.phone}">${e.phone}</a></p>`:""}
        </div>

        ${e.bookingType||e.bookingItem||e.eventDate||e.eventLocation?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Buchungsdetails</h3>
          ${e.bookingType?`<p><strong>Buchungstyp:</strong> ${e.bookingType}</p>`:""}
          ${e.bookingItem?`<p><strong>Gebuchtes Item:</strong> ${e.bookingItem}</p>`:""}
          ${e.eventDate?`<p><strong>Event-Datum:</strong> ${e.eventDate}</p>`:""}
          ${e.eventLocation?`<p><strong>Event-Ort:</strong> ${e.eventLocation}</p>`:""}
          ${e.eventType?`<p><strong>Event-Typ:</strong> ${e.eventType}</p>`:""}
        </div>
        `:""}

        ${e.message?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Nachricht</h3>
          <p style="white-space: pre-wrap;">${e.message.replace(/\n/g,"<br>")}</p>
        </div>
        `:""}

        ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
        <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
          <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
          ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
          ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
          ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
          ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
        </div>
        `:""}
      </body>
    </html>
  `,i=`Neue ${n}

Kontaktinformationen:
Name: ${e.name}
E-Mail: ${e.email}
${e.phone?`Telefon: ${e.phone}
`:""}
${e.bookingType||e.bookingItem||e.eventDate||e.eventLocation?`Buchungsdetails:
${e.bookingType?`Buchungstyp: ${e.bookingType}
`:""}${e.bookingItem?`Gebuchtes Item: ${e.bookingItem}
`:""}${e.eventDate?`Event-Datum: ${e.eventDate}
`:""}${e.eventLocation?`Event-Ort: ${e.eventLocation}
`:""}${e.eventType?`Event-Typ: ${e.eventType}
`:""}
`:""}${e.message?`Nachricht:
${e.message}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,l=[];if(a)try{let e=await s.emails.send({from:o,to:a,subject:t,html:r,text:i});e.error?console.warn(`⚠️ ${a} Fehler:`,e.error):(console.log(`✅ Kontakt-Benachrichtigung an ${a} gesendet`),l.push({email:a,id:e.data?.id}))}catch(e){console.error(`❌ Fehler beim Senden an ${a}:`,e)}if(0===l.length)try{let e=await s.emails.send({from:o,to:"roland.luthi@gmail.com",subject:t,html:r,text:i});e.error||(console.log("✅ Kontakt-Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback)"),l.push({email:"roland.luthi@gmail.com",id:e.data?.id}))}catch(e){console.error("❌ Fehler:",e)}return l.length>0?{id:l[0].id,data:{results:l}}:{error:"Keine E-Mails versendet"}}async function c(e,n){return s?await s.emails.send({from:o,to:e,subject:"Willkommen beim Inclusions Newsletter!",html:`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.8; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; font-size: 16px;">
          <h1 style="color: #ff00ff; font-size: 24px; margin-bottom: 20px;">Liebe / Lieber ${n}</h1>
          <p style="font-size: 18px; margin-bottom: 15px;">Herzlichen Dank f\xfcr deine Anmeldung.</p>
          <p style="margin-bottom: 15px;">Du bist nun Teil der Inclusions-Freunde und wirst regelm\xe4ssig informiert.</p>
          <p style="margin-top: 30px;">Bis bald,<br>Dein Inclusions Team</p>
        </body>
      </html>
    `,text:`Liebe / Lieber ${n}

Herzlichen Dank f\xfcr deine Anmeldung.

Du bist nun Teil der Inclusions-Freunde und wirst regelm\xe4ssig informiert.

Bis bald,
Dein Inclusions Team`}):{error:"Resend nicht konfiguriert"}}async function u(e){if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:262",message:"sendNewsletterNotification called",data:{email:e.email,resendIsNull:null===s,fromEmail:o,adminEmail:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),!s)return fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:274",message:"Resend is null - returning error",data:{email:e.email},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{}),{error:"Resend nicht konfiguriert"};let n=`📬 Newsletter-Anmeldung${e.firstName||e.lastName?`: ${[e.firstName,e.lastName].filter(Boolean).join(" ")}`:""} - Inclusions`,t=`
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #ff00ff;">📬 Neue Newsletter-Anmeldung</h2>
        
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
          <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
          ${e.firstName?`<p><strong>Vorname:</strong> ${e.firstName}</p>`:""}
          ${e.lastName?`<p><strong>Nachname:</strong> ${e.lastName}</p>`:""}
          ${void 0!==e.hasDisability?`<p><strong>Menschen mit Beeintr\xe4chtigung:</strong> ${e.hasDisability?"Ja":"Nein"}</p>`:""}
        </div>

        ${e.interests&&e.interests.length>0?`
        <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
          <h3 style="margin-top: 0; color: #333;">Interessen</h3>
          <p>${e.interests.join(", ")}</p>
        </div>
        `:""}

        ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
        <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
          <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
          ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
          ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
          ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
          ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
        </div>
        `:""}
      </body>
    </html>
  `,r=`📬 Neue Newsletter-Anmeldung

Kontaktinformationen:
E-Mail: ${e.email}
${e.firstName?`Vorname: ${e.firstName}
`:""}${e.lastName?`Nachname: ${e.lastName}
`:""}${void 0!==e.hasDisability?`Menschen mit Beeintr\xe4chtigung: ${e.hasDisability?"Ja":"Nein"}
`:""}
${e.interests&&e.interests.length>0?`Interessen: ${e.interests.join(", ")}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,i=[];if(a)try{fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:321",message:"Sending notification email to admin",data:{from:o,to:a},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{});let e=await s.emails.send({from:o,to:a,subject:n,html:t,text:r});if(fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:330",message:"Notification email result",data:{hasError:!!e.error,error:e.error,errorMessage:e.error?.message,errorName:e.error?.name,errorStatusCode:e.error?.statusCode,hasData:!!e.data,emailId:e.data?.id,fullResult:JSON.stringify(e)},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H1,H2,H3,H5"})}).catch(()=>{}),e.error){let n={error:e.error,message:e.error?.message,name:e.error?.name,statusCode:e.error?.statusCode,from:o,to:a};console.error(`❌ ${a} Fehler (Newsletter Notification):`,JSON.stringify(n,null,2)),e.error?.message?.includes("not authorized")||e.error?.message?.includes("Not authorized")?console.error("\uD83D\uDD34 PROBLEM: Domain nicht verifiziert! Gehe zu https://resend.com/domains und verifiziere inclusions.zone"):e.error?.message?.includes("Invalid API key")||e.error?.statusCode===401?console.error("\uD83D\uDD34 PROBLEM: API Key ung\xfcltig! Pr\xfcfe RESEND_API_KEY in .env"):e.error?.message?.includes("domain")&&console.error("\uD83D\uDD34 PROBLEM: Domain-Problem! Pr\xfcfe Domain-Verifizierung in Resend Dashboard")}else console.log(`✅ Newsletter-Benachrichtigung an ${a} gesendet`),i.push({email:a,id:e.data?.id})}catch(e){fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:337",message:"Exception sending notification email",data:{error:e instanceof Error?e.message:String(e)},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H5"})}).catch(()=>{}),console.error(`❌ Fehler beim Senden an ${a}:`,e)}if(0===i.length)try{let e=await s.emails.send({from:o,to:"roland.luthi@gmail.com",subject:n,html:t,text:r});e.error||(console.log("✅ Newsletter-Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback)"),i.push({email:"roland.luthi@gmail.com",id:e.data?.id}))}catch(e){console.error("❌ Fehler:",e)}return i.length>0?{id:i[0].id,data:{results:i}}:{error:"Keine E-Mails versendet"}}async function p(e,n,t,r){if(!s)return console.error("❌ Resend nicht konfiguriert in sendVIPConfirmation"),{error:"Resend nicht konfiguriert"};try{let i=n.split(" ")[0],l="";t&&r?l=`am ${t} bei Inclusions 2 im ${r}`:t?l=`am ${t}`:r&&(l=`bei Inclusions 2 im ${r}`),console.log(`📧 Sende VIP-Best\xe4tigung an: ${e}`);let d=await s.emails.send({from:o,to:e,reply_to:a,subject:"Deine VIP-Anmeldung ist angekommen - Inclusions",html:`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.8; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; font-size: 16px;">
            <h1 style="color: #ff00ff; font-size: 24px; margin-bottom: 20px;">Liebe / Lieber ${i}</h1>
            <p style="font-size: 18px; margin-bottom: 15px;">Vielen Dank f\xfcr deine Anmeldung${l?` ${l}`:""}.</p>
            <p style="margin-bottom: 15px;">Falls wir noch Fragen haben, werden wir uns bei dir melden.</p>
            <p style="margin-bottom: 15px;">Vor dem Anlass wirst du noch Informationen erhalten.</p>
            <p style="margin-top: 30px;">Bis bald – wir freuen uns auf dich.</p>
            <p style="margin-top: 20px;">Herzlich<br>Dein Inclusions Team</p>
          </body>
        </html>
      `,text:`Liebe / Lieber ${i}

Vielen Dank f\xfcr deine Anmeldung${l?` ${l}`:""}.

Falls wir noch Fragen haben, werden wir uns bei dir melden.
Vor dem Anlass wirst du noch Informationen erhalten.

Bis bald – wir freuen uns auf dich.

Herzlich
Dein Inclusions Team`});if(d.error)return console.error("❌ Resend API Fehler:",d.error),{error:d.error};return console.log("✅ VIP-Best\xe4tigung gesendet, ID:",d.data?.id),{id:d.data?.id,data:d.data}}catch(e){return console.error("❌ Fehler beim Senden der VIP-Best\xe4tigung:",e),{error:e instanceof Error?e.message:"Unbekannter Fehler"}}}async function g(e){if(!s)return console.error("❌ Resend nicht konfiguriert in sendVIPNotification"),{error:"Resend nicht konfiguriert"};try{let n=`🎫 VIP-Anmeldung${e.eventDate?`: ${e.eventDate}`:""}${e.name?` - ${e.name}`:""} - Inclusions`,t=`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #ff00ff;">🎫 Neue VIP-Anmeldung</h2>
          
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Kontaktinformationen</h3>
            <p><strong>Name:</strong> ${e.name}</p>
            <p><strong>E-Mail:</strong> <a href="mailto:${e.email}">${e.email}</a></p>
            ${e.phone?`<p><strong>Telefon:</strong> <a href="tel:${e.phone}">${e.phone}</a></p>`:""}
            ${e.company?`<p><strong>Firma:</strong> ${e.company}</p>`:""}
          </div>

          ${e.eventDate||e.eventLocation||e.eventType||e.numberOfGuests||e.specialRequirements?`
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Event-Details</h3>
            ${e.eventDate?`<p><strong>Event-Datum:</strong> ${e.eventDate}</p>`:""}
            ${e.eventLocation?`<p><strong>Event-Ort:</strong> ${e.eventLocation}</p>`:""}
            ${e.eventType?`<p><strong>Event-Typ:</strong> ${e.eventType}</p>`:""}
            ${e.numberOfGuests?`<p><strong>Anzahl G\xe4ste:</strong> ${e.numberOfGuests}</p>`:""}
            ${e.specialRequirements?`<p><strong>Besondere Anforderungen:</strong><br>${e.specialRequirements.replace(/\n/g,"<br>")}</p>`:""}
          </div>
          `:""}

          ${e.message?`
          <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
            <h3 style="margin-top: 0; color: #333;">Nachricht</h3>
            <p style="white-space: pre-wrap;">${e.message.replace(/\n/g,"<br>")}</p>
          </div>
          `:""}

          ${e.sourceUrl||e.utmSource||e.utmMedium||e.utmCampaign?`
          <div style="background-color: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 20px; font-size: 12px; color: #666;">
            <h4 style="margin-top: 0; color: #666;">Tracking-Informationen</h4>
            ${e.sourceUrl?`<p><strong>Quelle:</strong> <a href="${e.sourceUrl}">${e.sourceUrl}</a></p>`:""}
            ${e.utmSource?`<p><strong>UTM Source:</strong> ${e.utmSource}</p>`:""}
            ${e.utmMedium?`<p><strong>UTM Medium:</strong> ${e.utmMedium}</p>`:""}
            ${e.utmCampaign?`<p><strong>UTM Campaign:</strong> ${e.utmCampaign}</p>`:""}
          </div>
          `:""}
        </body>
      </html>
    `,r=`🎫 Neue VIP-Anmeldung

Kontaktinformationen:
Name: ${e.name}
E-Mail: ${e.email}
${e.phone?`Telefon: ${e.phone}
`:""}${e.company?`Firma: ${e.company}
`:""}
${e.eventDate||e.eventLocation||e.eventType||e.numberOfGuests||e.specialRequirements?`Event-Details:
${e.eventDate?`Event-Datum: ${e.eventDate}
`:""}${e.eventLocation?`Event-Ort: ${e.eventLocation}
`:""}${e.eventType?`Event-Typ: ${e.eventType}
`:""}${e.numberOfGuests?`Anzahl G\xe4ste: ${e.numberOfGuests}
`:""}${e.specialRequirements?`Besondere Anforderungen: ${e.specialRequirements}
`:""}
`:""}${e.message?`Nachricht:
${e.message}

`:""}${e.sourceUrl?`Quelle: ${e.sourceUrl}
`:""}${e.utmSource?`UTM Source: ${e.utmSource}
`:""}${e.utmMedium?`UTM Medium: ${e.utmMedium}
`:""}${e.utmCampaign?`UTM Campaign: ${e.utmCampaign}
`:""}`,i=[];if(a){console.log(`📧 Sende VIP-Benachrichtigung an: ${a}`);try{let l=await s.emails.send({from:o,to:a,reply_to:e.email,subject:n,html:t,text:r});l.error?console.warn(`⚠️ ${a} Fehler:`,l.error):(console.log(`✅ Benachrichtigung an ${a} gesendet, ID:`,l.data?.id),i.push({email:a,id:l.data?.id}))}catch(e){console.error(`❌ Fehler beim Senden an ${a}:`,e)}}if(0===i.length){console.log(`📧 Sende VIP-Benachrichtigung an: roland.luthi@gmail.com (Fallback)`);try{let a=await s.emails.send({from:o,to:"roland.luthi@gmail.com",reply_to:e.email,subject:n,html:t,text:r});a.error?console.error("❌ Fehler bei roland.luthi@gmail.com:",a.error):(console.log("✅ Benachrichtigung an roland.luthi@gmail.com gesendet (Fallback), ID:",a.data?.id),i.push({email:"roland.luthi@gmail.com",id:a.data?.id}))}catch(e){console.error("❌ Fehler beim Senden an roland.luthi@gmail.com:",e)}}if(i.length>0)return{id:i[0].id,data:{results:i},success:!0};return{error:"Keine E-Mails konnten versendet werden"}}catch(e){return console.error("❌ Fehler beim Senden der VIP-Benachrichtigung:",e),{error:e instanceof Error?e.message:"Unbekannter Fehler"}}}fetch("http://127.0.0.1:7243/ingest/10419aa7-e8ae-40cb-b044-efefcfde0373",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({location:"lib/resend.ts:13",message:"Resend instance created",data:{resendIsNull:null===s,hasApiKey:!!i},timestamp:Date.now(),sessionId:"debug-session",runId:"run1",hypothesisId:"H4"})}).catch(()=>{})}};