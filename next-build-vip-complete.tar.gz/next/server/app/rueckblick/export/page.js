(()=>{var e={};e.id=5661,e.ids=[5661],e.modules={47849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},55403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},94749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},73482:(e,i,r)=>{"use strict";r.r(i),r.d(i,{GlobalError:()=>o.a,__next_app__:()=>u,originalPathname:()=>m,pages:()=>d,routeModule:()=>p,tree:()=>c});var t=r(50482),n=r(69108),s=r(62563),o=r.n(s),l=r(68300),a={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(a[e]=()=>l[e]);r.d(i,a);let c=["",{children:["rueckblick",{children:["export",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,64937)),"/Users/roland/Curser/inclusions-2.0/app/rueckblick/export/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,22799)),"/Users/roland/Curser/inclusions-2.0/app/rueckblick/layout.tsx"]}]},{layout:[()=>Promise.resolve().then(r.bind(r,17664)),"/Users/roland/Curser/inclusions-2.0/app/layout.tsx"],error:[()=>Promise.resolve().then(r.bind(r,20429)),"/Users/roland/Curser/inclusions-2.0/app/error.tsx"],"not-found":[()=>Promise.resolve().then(r.bind(r,1429)),"/Users/roland/Curser/inclusions-2.0/app/not-found.tsx"]}],d=["/Users/roland/Curser/inclusions-2.0/app/rueckblick/export/page.tsx"],m="/rueckblick/export/page",u={require:r,loadChunk:()=>Promise.resolve()},p=new t.AppPageRouteModule({definition:{kind:n.x.APP_PAGE,page:"/rueckblick/export/page",pathname:"/rueckblick/export",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},34214:(e,i,r)=>{Promise.resolve().then(r.bind(r,61949))},61949:(e,i,r)=>{"use strict";r.r(i),r.d(i,{default:()=>o});var t=r(95344),n=r(3729),s=r(50235);function o(){let[e,i]=(0,n.useState)("newsletter"),r=(0,s.Ln)(),o=()=>`<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inclusions R\xfcckblick</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
      background-color: #1a1a1a;
    }
    .header {
      text-align: center;
      padding: 30px 0;
      background: linear-gradient(135deg, #FF04D3 0%, #FFD700 50%, #00BFFF 100%);
      color: white;
      border-radius: 10px;
      margin-bottom: 30px;
    }
    .header h1 {
      margin: 0;
      font-size: 32px;
      font-weight: bold;
    }
    .intro {
      background-color: rgba(255, 255, 255, 0.1);
      padding: 20px;
      border-radius: 10px;
      margin-bottom: 30px;
      color: #fff;
    }
    .image-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
      margin-bottom: 30px;
    }
    .image-item {
      background-color: rgba(255, 255, 255, 0.05);
      border-radius: 10px;
      overflow: hidden;
    }
    .image-item img {
      width: 100%;
      height: auto;
      display: block;
    }
    .image-caption {
      padding: 15px;
      color: #fff;
    }
    .image-caption h3 {
      margin: 0 0 5px 0;
      font-size: 18px;
      color: #FF04D3;
    }
    .image-caption p {
      margin: 0;
      font-size: 14px;
      color: rgba(255, 255, 255, 0.8);
    }
    .footer {
      text-align: center;
      padding: 20px;
      background-color: rgba(255, 255, 255, 0.1);
      border-radius: 10px;
      color: #fff;
    }
    .footer a {
      color: #FF04D3;
      text-decoration: none;
    }
    @media (min-width: 600px) {
      .image-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>Inclusions R\xfcckblick</h1>
    <p>Unsere Reise - Von der ersten Idee bis zum erfolgreichen Event</p>
  </div>
  
  <div class="intro">
    <p>Am 27. September 2025 haben wir Geschichte geschrieben. \xdcber 400 Menschen – mit und ohne Beeintr\xe4chtigung – tanzten zusammen im Supermarket Z\xfcrich.</p>
    <p><strong>Energie. Verbindung. Menschlichkeit. Pure Freude.</strong></p>
  </div>
  
  <div class="image-grid">
${r.map(e=>`    <div class="image-item">
      <img src="/images/rueckblick/${e.filename}" alt="${e.title}" />
      <div class="image-caption">
        <h3>${e.title}</h3>
        <p>${e.description}</p>
      </div>
    </div>`).join("\n")}
  </div>
  
  <div class="footer">
    <p><strong>Die Reise geht weiter!</strong></p>
    <p>Inclusions 2 findet am 25. April 2026, 13:00 - 21:00 statt.</p>
    <p><a href="/events">Mehr Infos zum n\xe4chsten Event</a></p>
    <p><a href="">Zur Webseite</a></p>
  </div>
</body>
</html>`;return(0,t.jsxs)("main",{className:"min-h-screen max-w-4xl px-4 py-12 mx-auto space-y-8 text-white",children:[(0,t.jsxs)("div",{className:"space-y-4",children:[t.jsx("h1",{className:"text-4xl font-bold",children:"Newsletter & Social Media Export"}),t.jsx("p",{className:"text-lg text-white/80",children:"Exportiere den R\xfcckblick f\xfcr Newsletter oder Social Media"})]}),(0,t.jsxs)("div",{className:"rounded-3xl bg-white/10 p-8 space-y-6",children:[(0,t.jsxs)("div",{children:[t.jsx("h2",{className:"text-2xl font-semibold mb-4",children:"Export-Format w\xe4hlen"}),(0,t.jsxs)("div",{className:"flex gap-4",children:[t.jsx("button",{onClick:()=>i("newsletter"),className:`px-6 py-3 rounded-full font-semibold transition-colors ${"newsletter"===e?"bg-brand-pink text-black":"bg-white/10 text-white hover:bg-white/20"}`,children:"Newsletter (HTML)"}),t.jsx("button",{onClick:()=>i("social"),className:`px-6 py-3 rounded-full font-semibold transition-colors ${"social"===e?"bg-brand-pink text-black":"bg-white/10 text-white hover:bg-white/20"}`,children:"Social Media"})]})]}),"newsletter"===e&&(0,t.jsxs)("div",{className:"space-y-4",children:[t.jsx("h3",{className:"text-xl font-semibold",children:"Newsletter HTML Export"}),t.jsx("p",{className:"text-white/80",children:"Generiert eine HTML-Datei, die direkt in Newsletter-Systeme eingef\xfcgt werden kann. Die Bilder werden als relative URLs eingebettet und m\xfcssen auf dem Server verf\xfcgbar sein."}),(0,t.jsxs)("button",{onClick:()=>{let e=o(),i=new Blob([e],{type:"text/html"}),r=URL.createObjectURL(i),t=document.createElement("a");t.href=r,t.download="inclusions-rueckblick-newsletter.html",document.body.appendChild(t),t.click(),document.body.removeChild(t),URL.revokeObjectURL(r)},className:"inline-flex items-center gap-2 rounded-full bg-brand-pink px-6 py-3 text-lg font-semibold text-black hover:bg-brand-pink/90 transition-colors",children:[t.jsx("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:t.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"})}),"HTML herunterladen"]})]}),"social"===e&&(0,t.jsxs)("div",{className:"space-y-4",children:[t.jsx("h3",{className:"text-xl font-semibold",children:"Social Media Export"}),(0,t.jsxs)("p",{className:"text-white/80",children:["F\xfcr Social Media k\xf6nnen die einzelnen Bilder mit ihren Beschreibungen verwendet werden. Die Bilder befinden sich in: ",t.jsx("code",{className:"bg-white/10 px-2 py-1 rounded",children:"/public/images/rueckblick/"})]}),t.jsx("div",{className:"grid gap-4 md:grid-cols-2",children:r.slice(0,6).map(e=>(0,t.jsxs)("div",{className:"bg-white/5 rounded-2xl p-4",children:[t.jsx("p",{className:"font-semibold text-white mb-2",children:e.title}),t.jsx("p",{className:"text-sm text-white/70 mb-2",children:e.description}),(0,t.jsxs)("p",{className:"text-xs text-white/50",children:["Bild: ",t.jsx("code",{children:e.filename})]})]},e.id))}),t.jsx("p",{className:"text-sm text-white/60",children:"Tipp: Verwende die Bilder einzeln f\xfcr Instagram-Posts oder erstelle Collagen f\xfcr Facebook/LinkedIn."})]})]}),(0,t.jsxs)("div",{className:"rounded-2xl bg-blue-500/10 border border-blue-500/20 p-6",children:[t.jsx("h3",{className:"font-semibold text-white mb-2",children:"Hinweise"}),(0,t.jsxs)("ul",{className:"space-y-2 text-sm text-white/80",children:[t.jsx("li",{children:"• Newsletter: Stelle sicher, dass die Bilder auf einem \xf6ffentlich zug\xe4nglichen Server gehostet sind"}),t.jsx("li",{children:"• Social Media: Verwende die Bilder mit den Beschreibungen als Captions"}),t.jsx("li",{children:"• Alle Bilder sind optimiert f\xfcr Web und Social Media"})]})]})]})}},50235:(e,i,r)=>{"use strict";r.d(i,{bd:()=>s,Ln:()=>n});let t=JSON.parse('{"images":[{"id":1,"filename":"rueckblick-1.png","title":"Besichtigung Supermarket","description":"Erste Besichtigung des Veranstaltungsortes Supermarket Z\xfcrich","category":"start","order":1},{"id":2,"filename":"rueckblick-2.png","title":"Zusage Supermarket","description":"Sandro Bohnenblust vom Supermarket mit Reto und Roland","category":"start","order":2},{"id":3,"filename":"rueckblick-3.png","title":"DJ-Workshop bei insieme","description":"Workshop f\xfcr DJ-Pairing bei insieme Z\xfcrich","category":"workshops","order":3},{"id":4,"filename":"rueckblick-4.png","title":"Kochen f\xfcr die Crew","description":"Gemeinsames Kochen f\xfcr die Crew bei insieme","category":"crew","order":4},{"id":5,"filename":"rueckblick-5.png","title":"Crew-Essen bei insieme","description":"Gemeinsames Essen der Crew","category":"crew","order":5},{"id":6,"filename":"rueckblick-6.png","title":"Die Geburt der Dance Crew","description":"Entstehung der Inclusions Dance Crew","category":"dance-crew","order":6},{"id":7,"filename":"rueckblick-7.png","title":"M\xe4rz 2025: Launch der Webseite","description":"Launch der Inclusions Webseite im M\xe4rz 2025","category":"events","order":2},{"id":8,"filename":"rueckblick-8.png","title":"Inclusions Art - K\xfcnstler Marcel","description":"Kunstprojekt mit K\xfcnstler Marcel bei insieme","category":"inclusions-art","order":8},{"id":9,"filename":"rueckblick-9.png","title":"Promo-Ausflug Luzern Neubad","description":"Promotionsausflug nach Luzern ins Neubad","category":"kultur","order":9},{"id":10,"filename":"rueckblick-10.png","title":"DJ-Auftritt Galerie Club Z\xfcrich","description":"Inclusions DJ-Auftritt im Galerie Club Z\xfcrich","category":"dj-on-tour","order":10},{"id":11,"filename":"rueckblick-11.png","title":"DJ-Pairing im \xdcbungsraum","description":"DJ-Pairing Training im \xdcbungsraum","category":"workshops","order":11},{"id":12,"filename":"rueckblick-12.png","title":"Inclusions DJs beim insieme Sommerfest","description":"DJ-Auftritt beim insieme Sommerfest","category":"insieme-sommerfest","order":12},{"id":13,"filename":"rueckblick-13.png","title":"Food Truck beim insieme Sommerfest","description":"Inclusions Food Truck beim insieme Sommerfest","category":"insieme-sommerfest","order":13},{"id":14,"filename":"rueckblick-14.png","title":"Inclusions beim insieme Sommerfest","description":"Inclusions Aktivit\xe4ten beim insieme Sommerfest","category":"insieme-sommerfest","order":14},{"id":15,"filename":"joza-zeier.jpeg","title":"Mit Joza - wichtiger Unterst\xfctzer","description":"Joza Zeier (Watchman) - wichtiger Unterst\xfctzer von Inclusions","category":"sponsoren","order":15},{"id":16,"filename":"rueckblick-16.png","title":"Sponsor Manroof","description":"Manroof als wertvoller Sponsor von Inclusions","category":"sponsoren","order":16},{"id":17,"filename":"rueckblick-17.png","title":"Lunch mit Bar- und Club-Kommission","description":"Treffen mit der Bar- und Club-Kommission","category":"wertvolle-treffen","order":17},{"id":18,"filename":"rueckblick-18.png","title":"Dance Crew Hauptprobe","description":"Hauptprobe der Inclusions Dance Crew","category":"dance-crew","order":18},{"id":19,"filename":"rueckblick-19.png","title":"Ausflug Bundeshaus mit insieme","description":"Gemeinsamer Ausflug zum Bundeshaus mit insieme","category":"kultur","order":19},{"id":20,"filename":"rueckblick-20.png","title":"Die ersten Inclusions G\xe4ste","description":"Die ersten G\xe4ste bei einem Inclusions Event","category":"grosser-tag","order":20},{"id":21,"filename":"rueckblick-21.png","title":"Fullhouse und tolle Stimmung","description":"Volles Haus und tolle Stimmung von Anfang bis Ende","category":"grosser-tag","order":21},{"id":22,"filename":"rueckblick-22.png","title":"Inclusions Sound ber\xfchrt die G\xe4ste","description":"Die Musik von Inclusions ber\xfchrt die G\xe4ste","category":"grosser-tag","order":22},{"id":23,"filename":"rueckblick-23.png","title":"Debriefing mit Team","description":"Nachbesprechung mit dem Team nach dem Event","category":"abschluss","order":23},{"id":24,"filename":"rueckblick-24.png","title":"Die Reise geht weiter - Tanz am Morgen","description":"Tanz am Morgen mit Coco und Inclusions Brunch","category":"community-event","order":24}]}');function n(){return t.images.sort((e,i)=>e.order-i.order)}let s={start:"Januar 2025: Zusage vom Supermarket",workshops:"DJ Workshops & DJ Trainings w\xe4hrend dem Jahr",crew:"Crew Treffen im insieme Kulturlokal",sponsoren:"Sponsoren & Unterst\xfctzer",events:"M\xe4rz 2025 Launch der Webseite","insieme-sommerfest":"insieme Sommerfest","dj-on-tour":"Inclusions DJ's on Tour","wertvolle-treffen":"Wertvolle Treffen","grosser-tag":"Der grosse Tag der Inclusions",kultur:"Inclusions on Tour","inclusions-art":"Inclusions Art","dance-crew":"Die Dance Crew",abschluss:"Debriefing und die Reise geht weiter...","community-event":"Bereits im November: Inclusions Community Event"}},64937:(e,i,r)=>{"use strict";r.r(i),r.d(i,{$$typeof:()=>s,__esModule:()=>n,default:()=>o});let t=(0,r(86843).createProxy)(String.raw`/Users/roland/Curser/inclusions-2.0/app/rueckblick/export/page.tsx`),{__esModule:n,$$typeof:s}=t,o=t.default},22799:(e,i,r)=>{"use strict";r.r(i),r.d(i,{default:()=>s,metadata:()=>n});var t=r(25036);let n={title:"R\xfcckblick - Unsere Reise im ersten Jahr | Inclusions",description:"R\xfcckblick auf das erste Jahr von Inclusions: \xdcber 400 Menschen tanzten zusammen im Supermarket Z\xfcrich. Erlebe die Reise von der ersten Idee bis zum erfolgreichen Event mit DJ-Workshops, Dance Crew, Kunstprojekten und mehr.",openGraph:{title:"R\xfcckblick - Unsere Reise im ersten Jahr | Inclusions",description:"R\xfcckblick auf das erste Jahr von Inclusions: \xdcber 400 Menschen tanzten zusammen im Supermarket Z\xfcrich. Erlebe die Reise von der ersten Idee bis zum erfolgreichen Event.",images:[{url:"/images/rueckblick/rueckblick-21.png",width:1200,height:630,alt:"Inclusions Event im Supermarket Z\xfcrich - \xdcber 400 Menschen tanzen zusammen"}]}};function s({children:e}){return t.jsx(t.Fragment,{children:e})}}};var i=require("../../../webpack-runtime.js");i.C(e);var r=e=>i(i.s=e),t=i.X(0,[1638,3578,4227],()=>r(73482));module.exports=t})();