import { NextRequest, NextResponse } from 'next/server';
import { insertContactRequest } from '@/lib/db-json';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validierung
    if (!body.email || !body.name || !body.message) {
      return NextResponse.json(
        { success: false, message: 'Alle Felder sind erforderlich.' },
        { status: 400 }
      );
    }

    // Speichere in JSON
    const result = await insertContactRequest({
      name: body.name,
      email: body.email,
      phone: body.phone || null,
      subject: body.subject || 'Kontaktanfrage',
      message: body.message,
    });

    console.log('✅ Contact gespeichert:', result.data);

    return NextResponse.json({
      success: true,
      message: 'Vielen Dank für deine Nachricht!'
    });

  } catch (error) {
    console.error('❌ Contact Error:', error);
    return NextResponse.json(
      { success: false, message: 'Ein Fehler ist aufgetreten.' },
      { status: 500 }
    );
  }
}
