import { NextRequest, NextResponse } from 'next/server';
import { insertNewsletterSubscriber } from '@/lib/db-json';
import { sendEmail } from '@/lib/resend';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validierung
    if (!body.email) {
      return NextResponse.json(
        { success: false, message: 'E-Mail ist erforderlich.' },
        { status: 400 }
      );
    }

    // Speichere in JSON
    const result = await insertNewsletterSubscriber({
      email: body.email.toLowerCase().trim(),
      first_name: body.first_name || null,
      last_name: body.last_name || null,
      interests: body.interests || [],
      age_group: body.age_group || null,
      has_disability: body.has_disability || false,
      disability_type: body.disability_type || null,
      accessibility_needs: body.accessibility_needs || null,
    });

    console.log('✅ Newsletter gespeichert:', result.data);

    // Sende Bestätigungs-Email
    try {
      await sendEmail({
        to: body.email,
        subject: 'Newsletter-Anmeldung bestätigt - INCLUSIONS 2.0',
        html: `
          <h2>Willkommen bei INCLUSIONS!</h2>
          <p>Hallo ${body.first_name || 'Liebe/r'},</p>
          <p>Vielen Dank für deine Newsletter-Anmeldung!</p>
          <p>Wir halten dich über INCLUSIONS 2.0 auf dem Laufenden.</p>
          <p>Beste Grüsse,<br>Das INCLUSIONS Team</p>
        `
      });
      console.log('✅ Bestätigungs-Email versendet an:', body.email);
    } catch (emailError) {
      console.error('❌ Bestätigungs-Email Fehler:', emailError);
    }

    // Sende Notification an Admin
    try {
      await sendEmail({
        to: process.env.RESEND_ADMIN_EMAIL || 'info@inclusions.zone',
        subject: '📧 Neue Newsletter-Anmeldung',
        html: `
          <h3>Neue Newsletter-Anmeldung</h3>
          <p><strong>Email:</strong> ${body.email}</p>
          <p><strong>Name:</strong> ${body.first_name || ''} ${body.last_name || ''}</p>
          <p><strong>Interessen:</strong> ${body.interests?.join(', ') || 'Keine'}</p>
          <p><strong>Zeit:</strong> ${new Date().toLocaleString('de-CH')}</p>
        `
      });
      console.log('✅ Notification versendet an Admin');
    } catch (emailError) {
      console.error('❌ Notification Fehler:', emailError);
    }

    return NextResponse.json({
      success: true,
      message: 'Vielen Dank für deine Anmeldung! Wir haben dir eine Bestätigung per E-Mail gesendet.'
    });

  } catch (error) {
    console.error('❌ Newsletter Error:', error);
    return NextResponse.json(
      { success: false, message: 'Ein Fehler ist aufgetreten.' },
      { status: 500 }
    );
  }
}
