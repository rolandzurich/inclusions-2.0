import { NextRequest, NextResponse } from 'next/server';
import { insertVipRegistration } from '@/lib/db-json';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Validierung
    if (!body.email || !body.first_name || !body.last_name) {
      return NextResponse.json(
        { success: false, message: 'Name und E-Mail sind erforderlich.' },
        { status: 400 }
      );
    }

    // Speichere in JSON
    const result = await insertVipRegistration({
      first_name: body.first_name,
      last_name: body.last_name,
      email: body.email,
      phone: body.phone || null,
      company: body.company || null,
      guests: body.guests || 1,
    });

    console.log('✅ VIP gespeichert:', result.data);

    return NextResponse.json({
      success: true,
      message: 'Vielen Dank für deine VIP-Anmeldung!'
    });

  } catch (error) {
    console.error('❌ VIP Error:', error);
    return NextResponse.json(
      { success: false, message: 'Ein Fehler ist aufgetreten.' },
      { status: 500 }
    );
  }
}
