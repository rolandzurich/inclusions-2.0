import type { Metadata } from "next";
import { Bangers } from "next/font/google";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

const bangers = Bangers({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-bangers",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Inclusions 2.0",
  description: "Vom Event zur Bewegung – Inclusions"
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="de" className={bangers.variable}>
      <body className="bg-brand-gray text-white">
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
