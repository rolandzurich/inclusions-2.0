import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Hier würde normalerweise der E-Mail-Versand erfolgen
    // Für den Start loggen wir die Daten und senden eine Erfolgsantwort
    console.log("Booking-Anfrage erhalten:", body);

    // TODO: E-Mail-Versand implementieren (z.B. mit nodemailer, sendgrid, etc.)
    // Beispiel:
    // await sendEmail({
    //   to: "booking@inclusions.zone",
    //   subject: `Neue Booking-Anfrage: ${body.bookingItem}`,
    //   body: `...`
    // });

    return NextResponse.json(
      { success: true, message: "Booking-Anfrage wurde erfolgreich gesendet." },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error processing booking request:", error);
    return NextResponse.json(
      { success: false, message: "Fehler beim Verarbeiten der Anfrage." },
      { status: 500 }
    );
  }
}


