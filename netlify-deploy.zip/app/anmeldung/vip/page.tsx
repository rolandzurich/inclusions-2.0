"use client";

import { useState } from "react";

export default function VIPAnmeldungPage() {
  const [formData, setFormData] = useState({
    // Wer meldet an?
    anmeldungDurch: "selbst", // "selbst" oder "betreuer"
    
    // VIP-Daten
    vorname: "",
    nachname: "",
    adresse: "",
    email: "",
    telefon: "",
    alter: "",
    ivAusweis: "",
    beeintraechtigung: "",
    
    // Kontaktperson für Notfälle (optional)
    kontaktpersonName: "",
    kontaktpersonTelefon: "",
    brauchtKontaktperson: "nein", // "ja" oder "nein"
    
    // Event-Details
    ankunftszeit: "",
    tixiTaxi: "nein",
    tixiAdresse: "",
    
    // Betreuer
    brauchtBetreuer: "nein",
    betreuerName: "",
    betreuerTelefon: "",
    
    // Besondere Bedürfnisse
    besondereBeduerfnisse: "",
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const handleRadioChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    // VIP-Daten (immer erforderlich)
    if (!formData.vorname.trim()) {
      newErrors.vorname = "Vorname ist erforderlich";
    }
    if (!formData.nachname.trim()) {
      newErrors.nachname = "Nachname ist erforderlich";
    }
    if (!formData.adresse.trim()) {
      newErrors.adresse = "Adresse ist erforderlich";
    }
    if (!formData.email.trim()) {
      newErrors.email = "E-Mail ist erforderlich";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Bitte gib eine gültige E-Mail-Adresse ein";
    }
    if (!formData.telefon.trim()) {
      newErrors.telefon = "Telefonnummer ist erforderlich";
    }
    if (!formData.alter) {
      newErrors.alter = "Alter ist erforderlich";
    } else if (parseInt(formData.alter) < 20) {
      newErrors.alter = "Du musst mindestens 20 Jahre alt sein";
    }
    if (!formData.ivAusweis) {
      newErrors.ivAusweis = "Bitte gib an, ob du einen IV-Ausweis hast";
    }
    if (!formData.beeintraechtigung) {
      newErrors.beeintraechtigung = "Bitte gib an, ob du eine Beeinträchtigung hast";
    }
    if (!formData.ankunftszeit) {
      newErrors.ankunftszeit = "Bitte wähle eine Ankunftszeit";
    }

    // Kontaktperson (wenn benötigt)
    if (formData.brauchtKontaktperson === "ja") {
      if (!formData.kontaktpersonName.trim()) {
        newErrors.kontaktpersonName = "Name der Kontaktperson ist erforderlich";
      }
      if (!formData.kontaktpersonTelefon.trim()) {
        newErrors.kontaktpersonTelefon = "Telefonnummer der Kontaktperson ist erforderlich";
      }
    }

    // Betreuer (wenn benötigt)
    if (formData.brauchtBetreuer === "ja") {
      if (!formData.betreuerName.trim()) {
        newErrors.betreuerName = "Name des Betreuers ist erforderlich";
      }
      if (!formData.betreuerTelefon.trim()) {
        newErrors.betreuerTelefon = "Telefonnummer des Betreuers ist erforderlich";
      }
    }

    // TIXI-Taxi Adresse (wenn benötigt)
    if (formData.tixiTaxi === "ja" && !formData.tixiAdresse.trim()) {
      newErrors.tixiAdresse = "Bitte gib die Abholadresse an";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      // Hier würde normalerweise die Formular-Daten an einen Server gesendet werden
      console.log("VIP-Anmeldung:", formData);
      alert("Vielen Dank für deine VIP-Anmeldung! Wir melden uns bald bei dir.");
      // Formular zurücksetzen
      setFormData({
        anmeldungDurch: "selbst",
        vorname: "",
        nachname: "",
        adresse: "",
        email: "",
        telefon: "",
        alter: "",
        ivAusweis: "",
        beeintraechtigung: "",
        kontaktpersonName: "",
        kontaktpersonTelefon: "",
        brauchtKontaktperson: "nein",
        ankunftszeit: "",
        tixiTaxi: "nein",
        tixiAdresse: "",
        brauchtBetreuer: "nein",
        betreuerName: "",
        betreuerTelefon: "",
        besondereBeduerfnisse: "",
      });
    }
  };

  return (
    <main className="min-h-screen max-w-3xl px-4 py-12 mx-auto space-y-10 text-white">
      <section>
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-pink text-white text-sm font-semibold mb-4">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
          </svg>
          VIP-Anmeldung
        </div>
        <h1 className="text-4xl font-bold">VIP-Anmeldung für Inclusions</h1>
        <p className="mt-3 text-lg text-white/70">
          Du hast einen IV-Ausweis, eine Beeinträchtigung oder Behinderung? Dann melde dich hier als VIP-Gast an! 
          Die Anmeldung ist wichtig, damit wir sicherstellen können, dass du gratis reinkommst und unser Helfer-Team 
          dich unterstützen kann, wenn du es brauchst.
        </p>
        
        <div className="mt-4 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
          <p className="text-sm text-white/90 mb-2">
            <strong className="text-white">Wichtig:</strong>
          </p>
          <ul className="text-sm text-white/80 space-y-1 list-disc list-inside">
            <li>Du musst mindestens 20 Jahre alt sein</li>
            <li>Nur VIPs kommen gratis rein – Freunde, Familie und Betreuer müssen ein Ticket kaufen</li>
            <li>Betreuer kommen nur gratis, wenn du auf 1-zu-1 Betreuung angewiesen bist</li>
            <li>Anmeldung im Vorfeld erforderlich</li>
          </ul>
        </div>
      </section>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Wer meldet an? */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Wer meldet an?</h2>
          <div className="space-y-3">
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="anmeldungDurch"
                value="selbst"
                checked={formData.anmeldungDurch === "selbst"}
                onChange={handleRadioChange}
                className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
              />
              <span className="ml-3">Ich melde mich selbst an</span>
            </label>
            <label className="flex items-center cursor-pointer">
              <input
                type="radio"
                name="anmeldungDurch"
                value="betreuer"
                checked={formData.anmeldungDurch === "betreuer"}
                onChange={handleRadioChange}
                className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
              />
              <span className="ml-3">Ich melde als Betreuer an</span>
            </label>
          </div>
        </div>

        {/* VIP-Daten */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Daten des VIP-Gasts</h2>
          
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label htmlFor="vorname" className="block text-sm font-semibold mb-2">
                  Vorname <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="text"
                  id="vorname"
                  name="vorname"
                  value={formData.vorname}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                    errors.vorname ? "border-red-500" : "border-white/20"
                  } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                  placeholder="Vorname"
                />
                {errors.vorname && (
                  <p className="mt-1 text-sm text-red-400">{errors.vorname}</p>
                )}
              </div>

              <div>
                <label htmlFor="nachname" className="block text-sm font-semibold mb-2">
                  Nachname <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="text"
                  id="nachname"
                  name="nachname"
                  value={formData.nachname}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                    errors.nachname ? "border-red-500" : "border-white/20"
                  } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                  placeholder="Nachname"
                />
                {errors.nachname && (
                  <p className="mt-1 text-sm text-red-400">{errors.nachname}</p>
                )}
              </div>
            </div>

            <div>
              <label htmlFor="adresse" className="block text-sm font-semibold mb-2">
                Adresse <span className="text-brand-pink">*</span>
              </label>
              <input
                type="text"
                id="adresse"
                name="adresse"
                value={formData.adresse}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                  errors.adresse ? "border-red-500" : "border-white/20"
                } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                placeholder="Strasse, PLZ Ort"
              />
              {errors.adresse && (
                <p className="mt-1 text-sm text-red-400">{errors.adresse}</p>
              )}
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label htmlFor="email" className="block text-sm font-semibold mb-2">
                  E-Mail <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                    errors.email ? "border-red-500" : "border-white/20"
                  } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                  placeholder="email@beispiel.ch"
                />
                {errors.email && (
                  <p className="mt-1 text-sm text-red-400">{errors.email}</p>
                )}
              </div>

              <div>
                <label htmlFor="telefon" className="block text-sm font-semibold mb-2">
                  Telefonnummer <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="tel"
                  id="telefon"
                  name="telefon"
                  value={formData.telefon}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                    errors.telefon ? "border-red-500" : "border-white/20"
                  } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                  placeholder="+41 XX XXX XX XX"
                />
                {errors.telefon && (
                  <p className="mt-1 text-sm text-red-400">{errors.telefon}</p>
                )}
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div>
                <label htmlFor="alter" className="block text-sm font-semibold mb-2">
                  Alter <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="number"
                  id="alter"
                  name="alter"
                  min="20"
                  value={formData.alter}
                  onChange={handleInputChange}
                  className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                    errors.alter ? "border-red-500" : "border-white/20"
                  } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                  placeholder="20"
                />
                {errors.alter && (
                  <p className="mt-1 text-sm text-red-400">{errors.alter}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-semibold mb-2">
                  Hast du einen IV-Ausweis? <span className="text-brand-pink">*</span>
                </label>
                <div className="space-y-2">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="ivAusweis"
                      value="ja"
                      checked={formData.ivAusweis === "ja"}
                      onChange={handleRadioChange}
                      className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                    />
                    <span className="ml-3">Ja</span>
                  </label>
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name="ivAusweis"
                      value="nein"
                      checked={formData.ivAusweis === "nein"}
                      onChange={handleRadioChange}
                      className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                    />
                    <span className="ml-3">Nein</span>
                  </label>
                </div>
                {errors.ivAusweis && (
                  <p className="mt-1 text-sm text-red-400">{errors.ivAusweis}</p>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold mb-2">
                Hast du eine Beeinträchtigung/Behinderung? <span className="text-brand-pink">*</span>
              </label>
              <div className="space-y-2">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="beeintraechtigung"
                    value="ja"
                    checked={formData.beeintraechtigung === "ja"}
                    onChange={handleRadioChange}
                    className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                  />
                  <span className="ml-3">Ja</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="beeintraechtigung"
                    value="nein"
                    checked={formData.beeintraechtigung === "nein"}
                    onChange={handleRadioChange}
                    className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                  />
                  <span className="ml-3">Nein</span>
                </label>
              </div>
              {errors.beeintraechtigung && (
                <p className="mt-1 text-sm text-red-400">{errors.beeintraechtigung}</p>
              )}
            </div>
          </div>
        </div>

        {/* Kontaktperson für Notfälle */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Kontaktperson für Notfälle</h2>
          <p className="text-sm text-white/70 mb-4">
            Falls du selbständig bist und keine Kontaktperson brauchst, kannst du diesen Abschnitt überspringen.
          </p>
          
          <div className="mb-4">
            <label className="block text-sm font-semibold mb-3">
              Brauchst du eine Kontaktperson für Notfälle?
            </label>
            <div className="space-y-2">
              <label className="flex items-center cursor-pointer">
                <input
                  type="radio"
                  name="brauchtKontaktperson"
                  value="ja"
                  checked={formData.brauchtKontaktperson === "ja"}
                  onChange={handleRadioChange}
                  className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                />
                <span className="ml-3">Ja</span>
              </label>
              <label className="flex items-center cursor-pointer">
                <input
                  type="radio"
                  name="brauchtKontaktperson"
                  value="nein"
                  checked={formData.brauchtKontaktperson === "nein"}
                  onChange={handleRadioChange}
                  className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                />
                <span className="ml-3">Nein</span>
              </label>
            </div>
          </div>

          {formData.brauchtKontaktperson === "ja" && (
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label htmlFor="kontaktpersonName" className="block text-sm font-semibold mb-2">
                    Name <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="text"
                    id="kontaktpersonName"
                    name="kontaktpersonName"
                    value={formData.kontaktpersonName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                      errors.kontaktpersonName ? "border-red-500" : "border-white/20"
                    } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                    placeholder="Name der Kontaktperson"
                  />
                  {errors.kontaktpersonName && (
                    <p className="mt-1 text-sm text-red-400">{errors.kontaktpersonName}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="kontaktpersonTelefon" className="block text-sm font-semibold mb-2">
                    Telefonnummer <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="tel"
                    id="kontaktpersonTelefon"
                    name="kontaktpersonTelefon"
                    value={formData.kontaktpersonTelefon}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                      errors.kontaktpersonTelefon ? "border-red-500" : "border-white/20"
                    } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                    placeholder="+41 XX XXX XX XX"
                  />
                  {errors.kontaktpersonTelefon && (
                    <p className="mt-1 text-sm text-red-400">{errors.kontaktpersonTelefon}</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Event-Details */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Event-Details</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="ankunftszeit" className="block text-sm font-semibold mb-2">
                Wann möchtest du kommen? <span className="text-brand-pink">*</span>
              </label>
              <select
                id="ankunftszeit"
                name="ankunftszeit"
                value={formData.ankunftszeit}
                onChange={handleInputChange}
                className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                  errors.ankunftszeit ? "border-red-500" : "border-white/20"
                } text-white focus:outline-none focus:ring-2 focus:ring-brand-pink`}
              >
                <option value="">-- Bitte wählen --</option>
                <option value="13-17">13:00 - 17:00 Uhr</option>
                <option value="17-21">17:00 - 21:00 Uhr</option>
                <option value="ganze-zeit">Ganze Zeit (13:00 - 21:00 Uhr)</option>
              </select>
              {errors.ankunftszeit && (
                <p className="mt-1 text-sm text-red-400">{errors.ankunftszeit}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-3">
                Möchtest du von TIXI-Taxi abgeholt werden?
              </label>
              <div className="space-y-2">
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="tixiTaxi"
                    value="ja"
                    checked={formData.tixiTaxi === "ja"}
                    onChange={handleRadioChange}
                    className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                  />
                  <span className="ml-3">Ja</span>
                </label>
                <label className="flex items-center cursor-pointer">
                  <input
                    type="radio"
                    name="tixiTaxi"
                    value="nein"
                    checked={formData.tixiTaxi === "nein"}
                    onChange={handleRadioChange}
                    className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                  />
                  <span className="ml-3">Nein</span>
                </label>
              </div>
              
              {formData.tixiTaxi === "ja" && (
                <div className="mt-4">
                  <label htmlFor="tixiAdresse" className="block text-sm font-semibold mb-2">
                    Abholadresse <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="text"
                    id="tixiAdresse"
                    name="tixiAdresse"
                    value={formData.tixiAdresse}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                      errors.tixiAdresse ? "border-red-500" : "border-white/20"
                    } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                    placeholder="Strasse, PLZ Ort"
                  />
                  {errors.tixiAdresse && (
                    <p className="mt-1 text-sm text-red-400">{errors.tixiAdresse}</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Betreuer */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Betreuer</h2>
          <p className="text-sm text-white/70 mb-4">
            Falls du im Alltag auf eine 1-zu-1 Betreuung angewiesen bist, ist dein/e Betreuer:in auch ein VIP 
            und kommt gratis rein. Andere Betreuer müssen ein Ticket kaufen.
          </p>
          
          <div className="mb-4">
            <label className="block text-sm font-semibold mb-3">
              Brauchst du einen Betreuer, der mitkommen muss?
            </label>
            <div className="space-y-2">
              <label className="flex items-center cursor-pointer">
                <input
                  type="radio"
                  name="brauchtBetreuer"
                  value="ja"
                  checked={formData.brauchtBetreuer === "ja"}
                  onChange={handleRadioChange}
                  className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                />
                <span className="ml-3">Ja</span>
              </label>
              <label className="flex items-center cursor-pointer">
                <input
                  type="radio"
                  name="brauchtBetreuer"
                  value="nein"
                  checked={formData.brauchtBetreuer === "nein"}
                  onChange={handleRadioChange}
                  className="w-5 h-5 text-brand-pink bg-white/10 border-white/20 focus:ring-brand-pink focus:ring-2"
                />
                <span className="ml-3">Nein</span>
              </label>
            </div>
          </div>

          {formData.brauchtBetreuer === "ja" && (
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <label htmlFor="betreuerName" className="block text-sm font-semibold mb-2">
                    Name des Betreuers <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="text"
                    id="betreuerName"
                    name="betreuerName"
                    value={formData.betreuerName}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                      errors.betreuerName ? "border-red-500" : "border-white/20"
                    } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                    placeholder="Name des Betreuers"
                  />
                  {errors.betreuerName && (
                    <p className="mt-1 text-sm text-red-400">{errors.betreuerName}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="betreuerTelefon" className="block text-sm font-semibold mb-2">
                    Telefonnummer <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="tel"
                    id="betreuerTelefon"
                    name="betreuerTelefon"
                    value={formData.betreuerTelefon}
                    onChange={handleInputChange}
                    className={`w-full px-4 py-3 rounded-lg bg-white/10 border ${
                      errors.betreuerTelefon ? "border-red-500" : "border-white/20"
                    } text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink`}
                    placeholder="+41 XX XXX XX XX"
                  />
                  {errors.betreuerTelefon && (
                    <p className="mt-1 text-sm text-red-400">{errors.betreuerTelefon}</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Besondere Bedürfnisse */}
        <div className="rounded-2xl bg-white/5 p-6 border border-white/10">
          <h2 className="text-xl font-semibold mb-4">Besondere Bedürfnisse</h2>
          <p className="text-sm text-white/70 mb-4">
            Gibt es wichtige Informationen, die unser Helfer-Team wissen sollte?
          </p>
          <textarea
            id="besondereBeduerfnisse"
            name="besondereBeduerfnisse"
            value={formData.besondereBeduerfnisse}
            onChange={handleInputChange}
            rows={4}
            className="w-full px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-brand-pink"
            placeholder="Z.B. spezielle Bedürfnisse, Allergien, wichtige Hinweise..."
          />
        </div>

        {/* Hinweis zu Tickets */}
        <div className="rounded-xl bg-yellow-500/10 border border-yellow-500/20 p-4">
          <p className="text-sm text-white/90">
            <strong className="text-white">Wichtig:</strong> Nur VIPs kommen gratis rein. Freunde, Familie 
            und andere Betreuer müssen ein Ticket über Supermarket kaufen. Betreuer kommen nur gratis, 
            wenn du auf 1-zu-1 Betreuung angewiesen bist.
          </p>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full rounded-full bg-brand-pink px-8 py-4 text-lg font-semibold text-black hover:bg-brand-pink/90 transition-colors"
        >
          VIP-Anmeldung absenden
        </button>
      </form>
    </main>
  );
}


