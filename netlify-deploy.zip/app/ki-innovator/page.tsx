import Image from "next/image";
import Link from "next/link";

export default function KIInnovatorPage() {
  return (
    <main className="min-h-screen max-w-6xl px-4 py-12 mx-auto space-y-16 text-white">
      {/* Hero Section */}
      <section className="space-y-8">
        <div className="relative w-full h-[400px] md:h-[500px] rounded-2xl overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-brand-pink/30 via-purple-500/20 to-blue-500/30 animate-float" />
          
          {/* Text Overlay */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4 z-10">
            <div className="space-y-4 animate-fade-in w-full">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white [text-shadow:_2px_2px_8px_rgb(0_0_0_/_90%)]">
                KI-First Social Innovator
              </h1>
              <p className="text-xl md:text-2xl text-white/90 max-w-3xl mx-auto [text-shadow:_1px_1px_4px_rgb(0_0_0_/_80%)]">
                Wie Inclusions KI-Technologie nutzt, um Inklusion zu fördern und Barrieren abzubauen
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Einführung */}
      <section className="space-y-6">
        <div className="rounded-3xl bg-gradient-to-br from-brand-pink/20 to-brand-pink/10 p-8 md:p-12 border-2 border-brand-pink/30">
          <div className="max-w-4xl mx-auto space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Was bedeutet "KI-First Social Innovator"?
            </h2>
            <p className="text-xl md:text-2xl text-white/90 leading-relaxed">
              Inclusions ist ein <strong className="text-white">KI-First Social Innovator</strong> – das bedeutet, 
              dass wir künstliche Intelligenz von Anfang an als Werkzeug nutzen, um soziale Innovation voranzutreiben 
              und echte Inklusion zu ermöglichen.
            </p>
            <p className="text-lg text-white/80 leading-relaxed">
              Während viele Organisationen KI als nachträgliche Ergänzung sehen, integrieren wir sie bewusst 
              in unsere Kernprozesse, um Barrieren abzubauen, Zugänglichkeit zu verbessern und neue Wege der 
              Kommunikation und Teilhabe zu schaffen.
            </p>
          </div>
        </div>
      </section>

      {/* KI-Anwendungen bei Inclusions */}
      <section className="space-y-8">
        <h2 className="text-3xl font-semibold text-white">Wie nutzt Inclusions KI?</h2>
        
        <div className="grid gap-6 md:grid-cols-2">
          {/* Voice Agent */}
          <article className="rounded-2xl bg-white/5 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-brand-pink/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-brand-pink" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-white">Voice Agent</h3>
            </div>
            <p className="text-white/80 leading-relaxed mb-4">
              Unser Voice Agent ermöglicht es Besuchern, mit der Website zu sprechen statt zu tippen. 
              Dies macht Inclusions für Menschen mit motorischen Einschränkungen, Sehbehinderungen oder 
              anderen Barrieren beim Tippen zugänglicher.
            </p>
            <ul className="space-y-2 text-white/70 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-brand-pink mt-1">•</span>
                <span>Spracherkennung für einfache Interaktion</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-brand-pink mt-1">•</span>
                <span>KI-gestützte Antworten auf Fragen zu Inclusions</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-brand-pink mt-1">•</span>
                <span>Sprachausgabe für barrierefreie Kommunikation</span>
              </li>
            </ul>
          </article>

          {/* Barrierefreie Kommunikation */}
          <article className="rounded-2xl bg-white/5 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-white">Barrierefreie Kommunikation</h3>
            </div>
            <p className="text-white/80 leading-relaxed mb-4">
              KI hilft uns, Informationen in verschiedenen Formaten bereitzustellen – von Text zu Sprache, 
              von komplexen Texten zu einfacher Sprache, und von einer Sprache zur anderen.
            </p>
            <ul className="space-y-2 text-white/70 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>Mehrsprachige Unterstützung</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>Einfache Sprache für besseres Verständnis</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">•</span>
                <span>Personalisierte Informationsbereitstellung</span>
              </li>
            </ul>
          </article>

          {/* Event-Organisation */}
          <article className="rounded-2xl bg-white/5 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-white">Intelligente Event-Organisation</h3>
            </div>
            <p className="text-white/80 leading-relaxed mb-4">
              KI unterstützt uns bei der Planung und Durchführung inklusiver Events, indem sie hilft, 
              Bedürfnisse zu erkennen, Ressourcen optimal zu verteilen und individuelle Unterstützung 
              zu koordinieren.
            </p>
            <ul className="space-y-2 text-white/70 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-green-400 mt-1">•</span>
                <span>Automatisierte Anmeldungsprozesse</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-400 mt-1">•</span>
                <span>Individuelle Bedarfsanalyse</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-400 mt-1">•</span>
                <span>Optimierte Ressourcenplanung</span>
              </li>
            </ul>
          </article>

          {/* Kontinuierliche Verbesserung */}
          <article className="rounded-2xl bg-white/5 p-6 hover:bg-white/10 transition-all">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <svg className="w-6 h-6 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold text-white">Kontinuierliche Verbesserung</h3>
            </div>
            <p className="text-white/80 leading-relaxed mb-4">
              Durch KI-Analysen lernen wir kontinuierlich dazu: Was funktioniert? Wo gibt es Barrieren? 
              Wie können wir unsere Angebote noch inklusiver gestalten?
            </p>
            <ul className="space-y-2 text-white/70 text-sm">
              <li className="flex items-start gap-2">
                <span className="text-yellow-400 mt-1">•</span>
                <span>Feedback-Analyse zur Identifikation von Barrieren</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-yellow-400 mt-1">•</span>
                <span>Datenbasierte Entscheidungen für mehr Inklusion</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-yellow-400 mt-1">•</span>
                <span>Vorhersage von Bedürfnissen und Anpassungen</span>
              </li>
            </ul>
          </article>
        </div>
      </section>

      {/* Warum KI-First? */}
      <section className="space-y-6 rounded-3xl bg-white/5 p-8 md:p-12">
        <h2 className="text-3xl md:text-4xl font-bold text-white">
          Warum "KI-First"?
        </h2>
        <div className="space-y-6 text-white/90">
          <div className="space-y-3">
            <h3 className="text-xl font-semibold text-white">Von Anfang an integriert</h3>
            <p className="leading-relaxed">
              Viele Organisationen fügen KI als nachträgliche Ergänzung hinzu. Bei Inclusions ist KI 
              Teil unserer DNA – wir denken von Anfang an darüber nach, wie Technologie Inklusion 
              fördern kann, nicht wie wir sie später hinzufügen können.
            </p>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-xl font-semibold text-white">Menschen im Mittelpunkt</h3>
            <p className="leading-relaxed">
              KI-First bedeutet nicht Technologie-First. Es bedeutet, dass wir die besten verfügbaren 
              Werkzeuge nutzen, um Menschen zu unterstützen. Die Technologie dient dem Zweck, nicht umgekehrt.
            </p>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-xl font-semibold text-white">Skalierbare Lösungen</h3>
            <p className="leading-relaxed">
              Durch KI können wir unsere Angebote skalieren, ohne die Qualität zu verlieren. Was für 
              eine Person funktioniert, kann für viele funktionieren – angepasst an individuelle Bedürfnisse.
            </p>
          </div>
        </div>
      </section>

      {/* Zukunftsvision */}
      <section className="space-y-6 rounded-3xl bg-gradient-to-br from-brand-pink/20 to-purple-500/20 p-8 md:p-12 border-2 border-brand-pink/30">
        <h2 className="text-3xl md:text-4xl font-bold text-white">
          Unsere Vision: KI für alle
        </h2>
        <div className="space-y-4 text-white/90">
          <p className="text-lg leading-relaxed">
            Wir glauben, dass KI ein mächtiges Werkzeug für soziale Gerechtigkeit sein kann. 
            Inclusions zeigt, wie Technologie genutzt werden kann, um Barrieren abzubauen statt 
            sie zu errichten.
          </p>
          <p className="leading-relaxed">
            In Zukunft wollen wir noch mehr KI-Technologien einsetzen:
          </p>
          <ul className="space-y-2 text-white/80">
            <li className="flex items-start gap-2">
              <span className="text-brand-pink mt-1">•</span>
              <span>KI-gestützte Übersetzungen in Echtzeit für mehrsprachige Events</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-pink mt-1">•</span>
              <span>Personalisierte Event-Empfehlungen basierend auf individuellen Bedürfnissen</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-pink mt-1">•</span>
              <span>Automatisierte Barrierefreiheits-Checks für Veranstaltungsorte</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-brand-pink mt-1">•</span>
              <span>KI-gestützte Assistenzsysteme für Menschen mit verschiedenen Beeinträchtigungen</span>
            </li>
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="space-y-6 text-center">
        <h2 className="text-3xl font-semibold text-white">
          Erlebe KI-gestützte Inklusion
        </h2>
        <p className="text-lg text-white/80 max-w-2xl mx-auto">
          Probiere unseren Voice Agent auf der Startseite aus oder werde Teil unserer Bewegung.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-full bg-brand-pink px-6 py-3 text-lg font-semibold text-black hover:bg-brand-pink/90 transition-colors"
          >
            <span>Zur Startseite</span>
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </Link>
          <Link
            href="/events"
            className="inline-flex items-center gap-2 rounded-full border border-brand-pink px-6 py-3 text-lg font-semibold text-brand-pink hover:bg-brand-pink hover:text-black transition-colors"
          >
            <span>Events entdecken</span>
          </Link>
        </div>
      </section>
    </main>
  );
}
