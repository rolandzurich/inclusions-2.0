"use client";

import Link from "next/link";
import Image from "next/image";
import { useState } from "react";

const navLinks = [
  { href: "/events", label: "Events" },
  { href: "/rueckblick", label: "Rückblick" },
  { href: "/djs", label: "DJ's" },
  { href: "/dance-crew", label: "Dance Crew" },
  { href: "/medien", label: "Medien" },
  { href: "/ueber-uns", label: "Über uns" },
];

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="bg-brand-dark sticky top-0 z-50 border-b border-white/10">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4">
        <Link href="/" className="flex items-center">
          <Image
            src="/images/inclusions-logo.png"
            alt="Inclusions Logo"
            width={200}
            height={60}
            className="h-20 w-auto"
            priority
          />
        </Link>
        <nav className="hidden items-center gap-6 text-sm font-semibold text-white lg:flex">
          <Link
            href="/anmeldung"
            className="rounded-full border border-brand-pink px-4 py-2 text-sm font-bold text-brand-pink hover:bg-brand-pink hover:text-brand-dark transition-colors"
          >
            Newsletter
          </Link>
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} className="hover:text-brand-pink">
              {link.label}
            </Link>
          ))}
          <Link
            href="/spenden"
            className="rounded-full bg-brand-pink px-4 py-2 text-sm font-bold text-brand-dark"
          >
            Spenden
          </Link>
        </nav>
        <button
          className="lg:hidden"
          aria-label="Menü öffnen"
          onClick={() => setOpen((prev) => !prev)}
        >
          <div className="space-y-1">
            <span className="block h-0.5 w-6 bg-white" />
            <span className="block h-0.5 w-6 bg-white" />
            <span className="block h-0.5 w-6 bg-white" />
          </div>
        </button>
      </div>
      {open && (
        <div className="bg-brand-dark lg:hidden">
          <div className="space-y-4 px-4 pb-6 pt-2 text-lg">
            <Link
              href="/anmeldung"
              className="block text-brand-pink font-bold"
              onClick={() => setOpen(false)}
            >
              Newsletter
            </Link>
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block text-white"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <Link
              href="/spenden"
              className="block text-brand-pink font-bold"
              onClick={() => setOpen(false)}
            >
              Spenden
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}

